'use strict';
/* Builds dist/site/: the whole public website as plain files you can open by double-clicking index.html,
   upload to any static host, or send to someone as a zip. It has no backend, so bookings fall back to
   email and WhatsApp, and there are no reviews or projects. Run:  npm run build:preview */
const fs = require('node:fs');
const path = require('node:path');
const { createPages } = require('../server/pages');
const { DEFAULT_SETTINGS } = require('../server/store');

const root = path.join(__dirname, '..'), out = path.join(root, 'dist', 'site');
const pages = createPages({ publicDir: path.join(root, 'public'), partialsDir: path.join(root, 'partials'), publicUrl: '' });
const routes = new Set(pages.routes);

/* "/services#deep" -> "services.html#deep", "/css/site.css" -> "css/site.css" */
function relink(url) {
  const m = /^\/([^?#]*)([?#].*)?$/.exec(url); if (!m) return url;
  const p = '/' + m[1], tail = m[2] || '';
  if (p === '/') return 'index.html' + tail;
  if (routes.has(p)) return m[1] + '.html' + tail;
  return m[1] + tail;
}
const fix = (text) => text.replace(/\b(href|src)="(\/[^"]*)"/g, (all, attr, url) => attr + '="' + relink(url) + '"');

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });

pages.routes.forEach((r) => {
  let html = pages.render(r, DEFAULT_SETTINGS).html;
  html = html.replace(/<a href="\/admin\/">Staff login<\/a>/, '');
  fs.writeFileSync(path.join(out, (r === '/' ? 'index' : r.slice(1)) + '.html'), fix(html));
});
const nf = pages.render('/__missing', DEFAULT_SETTINGS).html.replace(/<a href="\/admin\/">Staff login<\/a>/, '');
fs.writeFileSync(path.join(out, '404.html'), fix(nf));

function copy(dir) {
  fs.mkdirSync(path.join(out, dir), { recursive: true });
  fs.readdirSync(path.join(root, 'public', dir)).forEach((f) => {
    const src = path.join(root, 'public', dir, f), dst = path.join(out, dir, f);
    if (/\.(js|css)$/.test(f)) fs.writeFileSync(dst, fix(fs.readFileSync(src, 'utf8'))); else fs.copyFileSync(src, dst);
  });
}
copy('css'); copy('js'); copy('img');
fs.copyFileSync(path.join(root, 'public', 'favicon.ico'), path.join(out, 'favicon.ico'));
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'public', 'site.webmanifest'), 'utf8'));
manifest.start_url = 'index.html'; manifest.scope = './'; manifest.icons.forEach((i) => { i.src = i.src.replace(/^\//, ''); });
fs.writeFileSync(path.join(out, 'site.webmanifest'), JSON.stringify(manifest, null, 2));

const count = fs.readdirSync(out).filter((f) => f.endsWith('.html')).length;
console.log('Wrote ' + path.relative(process.cwd(), out) + ' (' + count + ' pages). Open index.html to look around.');
