#!/usr/bin/env python3
"""
Builds every logo image the website uses from the original logo file.

    python3 scripts/make-logo-assets.py            (needs: pip install pillow numpy scipy)

The site itself does NOT need Python or these libraries: this only needs to run again if the logo changes.
Source:  assets/source/FreshNest_Logo.jpg   (white background)
Output:  public/img/*.png, public/favicon.ico

What it does
  * Cuts the white background away (transparent PNGs) so the logo works on light, dark and coloured backgrounds.
  * Splits the emblem into three layers that line up exactly: the green disc, the white droplet and the gold sparkle.
    The disc is rebuilt underneath the droplet and sparkle, so they can move on their own for the welcome animation.
  * Splits the text into the wordmark and the tagline, each in a dark version and a light version for dark backgrounds.
  * Makes favicons, a home-screen icon and a 1200x630 share image.
"""
import os
import sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from scipy import ndimage as ndi

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SRC = os.path.join(ROOT, 'assets', 'source', 'FreshNest_Logo.jpg')
OUT = os.path.join(ROOT, 'public', 'img')
os.makedirs(OUT, exist_ok=True)

TEXT_DARK = (1, 70, 68)          # the colour of the wordmark in the original logo
TEXT_LIGHT = (233, 244, 243)     # used on dark backgrounds
src = Image.open(SRC).convert('RGB')
A = np.array(src).astype(float)
H, W = A.shape[:2]
yy, xx = np.mgrid[0:H, 0:W]

# ---------------------------------------------------------------- emblem geometry
CX, CY, R = 116.5, 115.5, 116.0                       # fitted circle of the emblem in the source
rad = np.sqrt((xx - CX) ** 2 + (yy - CY) ** 2)
r, g, b = A[..., 0], A[..., 1], A[..., 2]
disc = rad <= R - 1.5
white = disc & (r > 120) & (abs(g - b) < 30) & (g > 120)         # droplet
yellow = disc & (g - b > 40) & (r > 150)                           # sparkle
silhouette = ndi.binary_fill_holes(white)                          # the whole droplet, including the green comma cut into it
fg = ndi.binary_dilation(silhouette | yellow, iterations=5)

# ---------------------------------------------------------------- model the green disc behind droplet and sparkle
def feats(X, Y, deg=3):
    return np.stack([(X ** i) * (Y ** j) for i in range(deg + 1) for j in range(deg + 1 - i)], axis=1)

known = (rad < 0.80 * R) & ~fg                                    # smooth inner disc only (the rim has its own shading)
F = feats((xx[known] - CX) / R, (yy[known] - CY) / R)
fit = np.zeros_like(A)
Fall = feats(((xx - CX) / R).ravel(), ((yy - CY) / R).ravel())
for ch in range(3):
    coef = np.linalg.lstsq(F, A[..., ch][known], rcond=None)[0]
    fit[..., ch] = (Fall @ coef).reshape(H, W)

# correct the low-frequency error near the hole edges so the repair has no visible seam
ring = ndi.binary_dilation(fg, iterations=7) & ~fg & (rad < 0.86 * R)
resid = A - fit
def diffuse(field, known_mask, sigma=6, passes=6):
    out = field.copy(); m = known_mask.astype(float)
    for _ in range(passes):
        num = np.stack([ndi.gaussian_filter(out[..., c] * m, sigma) for c in range(3)], axis=-1)
        den = ndi.gaussian_filter(m, sigma)[..., None]
        est = num / np.maximum(den, 1e-6)
        out = np.where(known_mask[..., None], field, est); m = np.where(known_mask | (den[..., 0] > 1e-4), 1.0, 0.0)
    return out
res_fill = diffuse(np.where(ring[..., None], resid, 0), ring)
base_est = np.clip(fit + res_fill, 0, 255)

hole = ndi.binary_dilation(silhouette | yellow, iterations=4)
w_hole = ndi.gaussian_filter(hole.astype(float), 1.0).clip(0, 1)[..., None]
base = A * (1 - w_hole) + base_est * w_hole                       # original everywhere except the repaired hole

# ---------------------------------------------------------------- foreground layers (colour + alpha) over that base
def layer(region, ref_channel_value):
    """alpha from the red channel (the disc is almost red-free, the layer is red-rich), colour un-mixed from the base."""
    denom = np.maximum(ref_channel_value - base[..., 0], 20.0)
    a = np.where(region, np.clip((r - base[..., 0]) / denom, 0, 1), 0.0)
    a[a < 0.02] = 0
    col = np.clip((A - (1 - a[..., None]) * base) / np.maximum(a[..., None], 1e-3), 0, 255)
    col[a == 0] = 0
    return col, a

star_zone = ndi.binary_dilation(yellow, iterations=4)
drop_zone = ndi.binary_dilation(silhouette, iterations=4) & ~star_zone
star_col, star_a = layer(star_zone, 253.0)
drop_col, drop_a = layer(drop_zone, 254.0)
# the green comma is part of the droplet picture (it is not see-through), so the droplet keeps it as solid pixels
inside = ndi.binary_erosion(silhouette, iterations=1)
drop_a = np.where(inside, 1.0, drop_a)
drop_col = np.where(inside[..., None], A, drop_col)

# check the three layers put back together match the original
recon = base * (1 - drop_a[..., None]) + drop_col * drop_a[..., None]
recon = recon * (1 - star_a[..., None]) + star_col * star_a[..., None]
diff = np.abs(recon - A)[rad < R - 3]
print('layers recombine to the original: mean error %.2f, 99th percentile %.1f, 99.9th %.1f (of 255)' % (diff.mean(), np.percentile(diff, 99), np.percentile(diff, 99.9)))
bad = (np.abs(recon - A).max(axis=2) > 15) & (rad < R - 3)
ys_, xs_ = np.where(bad); print('  pixels differing by more than 15: %d (%.2f%% of the emblem)' % (bad.sum(), 100 * bad.sum() / (rad < R - 3).sum()))

# ---------------------------------------------------------------- common canvas (236 x 236), antialiased circle mask
SIZE = 236
OFF = (1, 2)                                     # shifts the emblem so its circle is centred on the canvas
def to_canvas(arr_rgb, alpha):
    rgba = np.dstack([arr_rgb, alpha * 255]).clip(0, 255).astype(np.uint8)
    img = Image.fromarray(rgba, 'RGBA')
    canvas = Image.new('RGBA', (SIZE, SIZE), (0, 0, 0, 0))
    canvas.paste(img.crop((0, 0, SIZE - OFF[0], SIZE - OFF[1])), OFF)
    return canvas

SS = 8
m = Image.new('L', (SIZE * SS, SIZE * SS), 0)
cxm, cym, rm = (CX + OFF[0]) * SS, (CY + OFF[1]) * SS, (R - 1.4) * SS            # 1.4px inside the edge removes the white fringe
ImageDraw.Draw(m).ellipse([cxm - rm, cym - rm, cxm + rm, cym + rm], fill=255)
circle_mask = m.resize((SIZE, SIZE), Image.LANCZOS)

def save(img, name, **kw):
    path = os.path.join(OUT, name); img.save(path, optimize=True, **kw)
    print('  %-28s %4dx%-4d %6.1f KB' % (name, img.width, img.height, os.path.getsize(path) / 1024))
    return path

base_img = to_canvas(base, np.ones((H, W)))
base_img.putalpha(circle_mask)
drop_img = to_canvas(drop_col, drop_a)
star_img = to_canvas(star_col, star_a)

print('Emblem layers')
save(base_img, 'logo-disc.png')
save(drop_img, 'logo-droplet.png')
save(star_img, 'logo-sparkle.png')

mark = Image.alpha_composite(Image.alpha_composite(base_img, drop_img), star_img)
save(mark, 'logo-mark.png')
save(mark.resize((128, 128), Image.LANCZOS), 'logo-mark-128.png')

# where the layers sit inside the emblem, as percentages (the page CSS uses these)
def bbox(img):
    bb = img.getchannel('A').point(lambda v: 255 if v > 20 else 0).getbbox(); return bb
for nm, im_ in (('droplet', drop_img), ('sparkle', star_img)):
    x0, y0, x1, y1 = bbox(im_)
    print('  %-8s centre %.1f%% , %.1f%%   size %.1f%% x %.1f%%   bottom %.1f%%' % (nm, (x0 + x1) / 2 / SIZE * 100, (y0 + y1) / 2 / SIZE * 100, (x1 - x0) / SIZE * 100, (y1 - y0) / SIZE * 100, y1 / SIZE * 100))

# ---------------------------------------------------------------- text: transparent, in dark and light colours
def text_layer(box, name, pad=6):
    x0, y0, x1, y1 = box
    sub = A[y0:y1, x0:x1]
    lum = 0.299 * sub[..., 0] + 0.587 * sub[..., 1] + 0.114 * sub[..., 2]
    t_lum = 0.299 * TEXT_DARK[0] + 0.587 * TEXT_DARK[1] + 0.114 * TEXT_DARK[2]
    alpha = np.clip((255 - lum) / (255 - t_lum), 0, 1)
    alpha = np.clip((alpha - 0.05) / 0.90, 0, 1)                 # remove JPEG noise around the letters
    ys, xs = np.where(alpha > 0.3)
    bx0, by0, bx1, by1 = max(xs.min() - pad, 0), max(ys.min() - pad, 0), min(xs.max() + pad + 1, alpha.shape[1]), min(ys.max() + pad + 1, alpha.shape[0])
    alpha = alpha[by0:by1, bx0:bx1]
    outs = {}
    for variant, colour in (('', TEXT_DARK), ('-light', TEXT_LIGHT)):
        rgba = np.zeros(alpha.shape + (4,), np.uint8); rgba[..., :3] = colour; rgba[..., 3] = (alpha * 255).astype(np.uint8)
        img = Image.fromarray(rgba, 'RGBA'); outs[variant] = img
        save(img, name + variant + '.png')
    return outs, (x0 + bx0, y0 + by0, x0 + bx1, y0 + by1)

print('Text')
word, word_box = text_layer((270, 8, W, 152), 'logo-word')
tag, tag_box = text_layer((270, 152, W, 226), 'logo-tag')
print('  wordmark box in source', word_box, ' tagline box', tag_box)
# Give the tagline picture the same width as the wordmark picture, with the tagline in its original position, so the
# page can stack the two at 100% width and they line up exactly as in the artwork.
ww = word['' ].width
for variant in ('', '-light'):
    padded = Image.new('RGBA', (ww, tag[variant].height), (0, 0, 0, 0))
    padded.paste(tag[variant], (tag_box[0] - word_box[0], 0))
    tag[variant] = padded
    save(padded, 'logo-tag' + variant + '.png')
tag_box = (word_box[0], tag_box[1], word_box[0] + ww, tag_box[3])

# ---------------------------------------------------------------- the whole logo in one picture (dark text, transparent)
# the emblem canvas is already offset by OFF, so place it so the circle returns to its source position
full_img = Image.new('RGBA', (W, H), (0, 0, 0, 0))
full_img.alpha_composite(mark, (-OFF[0], -OFF[1]))
full_img.alpha_composite(word[''], (word_box[0], word_box[1]))
full_img.alpha_composite(tag[''], (tag_box[0], tag_box[1]))
full_light = Image.new('RGBA', (W, H), (0, 0, 0, 0))
full_light.alpha_composite(mark, (-OFF[0], -OFF[1]))
full_light.alpha_composite(word['-light'], (word_box[0], word_box[1]))
full_light.alpha_composite(tag['-light'], (tag_box[0], tag_box[1]))
print('Whole logo')
save(full_img, 'logo-full.png')
save(full_light, 'logo-full-light.png')

# ---------------------------------------------------------------- favicons and home-screen icons
print('Icons')
ico_src = mark.resize((256, 256), Image.LANCZOS)
ico_src.save(os.path.join(ROOT, 'public', 'favicon.ico'), sizes=[(16, 16), (32, 32), (48, 48)])
print('  favicon.ico                  %6.1f KB' % (os.path.getsize(os.path.join(ROOT, 'public', 'favicon.ico')) / 1024))
save(mark.resize((32, 32), Image.LANCZOS), 'favicon-32.png')
save(mark.resize((192, 192), Image.LANCZOS), 'icon-192.png')
touch = Image.new('RGB', (180, 180), (255, 255, 255))                   # iOS fills transparency with black, so give it a white tile
em = mark.resize((148, 148), Image.LANCZOS); touch.paste(em, (16, 16), em)
save(touch, 'apple-touch-icon.png')

# ---------------------------------------------------------------- share picture (WhatsApp, Facebook, Google)
og = Image.new('RGB', (1200, 630), (255, 255, 255))
px = og.load()
for y in range(630):                                                      # soft mint-to-white wash, brand colours
    t = y / 629.0
    for x in range(1200):
        k = max(0.0, 1 - ((x - 1200) ** 2 + (y + 80) ** 2) ** 0.5 / 900)  # glow from the top-right corner
        px[x, y] = (int(255 - 18 * k - 6 * t), int(255 - 3 * k - 4 * t), int(255 - 14 * k - 8 * t))
lw = 940
lockup = full_img.resize((lw, int(H * lw / W)), Image.LANCZOS)
og.paste(lockup, ((1200 - lw) // 2, (630 - lockup.height) // 2), lockup)
save(og, 'og-image.png')
# ---------------------------------------------------------------- web copies: WebP is about a quarter of the weight of PNG
# The website uses the .webp files (fast on mobile data). The full-quality PNG masters are kept in assets/logo/ and are not served.
print('Web copies (WebP)')
MASTERS = os.path.join(ROOT, 'assets', 'logo'); os.makedirs(MASTERS, exist_ok=True)
for name, lossless in (('logo-mark-128', False), ('logo-disc', False), ('logo-droplet', False), ('logo-sparkle', False),
                       ('logo-word', True), ('logo-word-light', True), ('logo-tag', True), ('logo-tag-light', True)):
    png = os.path.join(OUT, name + '.png'); im = Image.open(png).convert('RGBA')
    web = os.path.join(OUT, name + '.webp')
    im.save(web, 'WEBP', **({'lossless': True} if lossless else {'quality': 90}), method=6)
    os.replace(png, os.path.join(MASTERS, name + '.png'))
    print('  %-28s %6.1f KB  (PNG master %.1f KB kept in assets/logo)' % (name + '.webp', os.path.getsize(web) / 1024, os.path.getsize(os.path.join(MASTERS, name + '.png')) / 1024))
print('Done.')
