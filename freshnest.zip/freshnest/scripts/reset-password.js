'use strict';
/* Sets a new admin password when the old one is lost:   npm run reset-password
   or choose your own:                                    npm run reset-password -- "my new password phrase"
   Stop the server first, then start it again afterwards. If ADMIN_PASSWORD is set on the server, that setting wins:
   change it there instead. */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = path.join(__dirname, '..');
require('../server/env').loadEnv(path.join(root, '.env'));
const { hashPassword } = require('../server/auth');

const file = path.join(process.env.DATA_DIR || path.join(root, 'data'), 'db.json');
if (!fs.existsSync(file)) { console.error('\nNo data found at ' + file + '.\nIf your data lives elsewhere, set DATA_DIR first. If this is a new install, just start the server: it creates a password for you.\n'); process.exit(1); }

let db;
try { db = JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) { console.error('\nCould not read ' + file + ': ' + e.message + '\n'); process.exit(1); }

const given = process.argv[2];
if (given !== undefined && given.length < 10) { console.error('\nUse at least 10 characters.\n'); process.exit(1); }
const password = given || crypto.randomBytes(9).toString('base64url');

db.meta = db.meta || {};
db.meta.adminHash = hashPassword(password);
db.meta.passwordChangedAt = new Date().toISOString();
fs.copyFileSync(file, file + '.before-reset');
const tmp = file + '.tmp';
fs.writeFileSync(tmp, JSON.stringify(db, null, 2), { mode: 0o600 }); fs.renameSync(tmp, file);

console.log('\nThe admin password has been reset.');
if (!given) console.log('New password:  ' + password + '\nSave it now. It is not shown again. You can change it under Settings after signing in.');
if (process.env.ADMIN_PASSWORD) console.log('\n! ADMIN_PASSWORD is set, so the server will still use that value instead. Change it there.');
console.log('\nNow start the server again. Anyone signed in before is signed out.\n');
