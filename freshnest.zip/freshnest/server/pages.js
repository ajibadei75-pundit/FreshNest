'use strict';
/* Builds the website's pages. Each page in public/ is a small HTML file; the shared head, header and footer live in
   partials/ and are pulled in with <!--include:name-->, so navigation is edited in exactly one place.
   The server also marks the current page in the menu and fills in search-engine details from the live settings. */
const fs = require('node:fs');
const path = require('node:path');
const Hours = require('../public/js/hours.js');
const Pricing = require('../public/js/pricing.js');

/* url path -> file name (without .html). Order is the order used in the sitemap. */
const ROUTES = {
  '/': 'index', '/services': 'services', '/book': 'book', '/locations': 'locations', '/work': 'work',
  '/reviews': 'reviews', '/faq': 'faq', '/contact': 'contact', '/terms': 'terms'
};
const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

function createPages(opts) {
  const publicDir = opts.publicDir, partialsDir = opts.partialsDir, publicUrl = opts.publicUrl || '';
  const read = (file) => fs.readFileSync(file, 'utf8');

  function includes(html) {
    for (let i = 0; i < 3 && /<!--include:/.test(html); i++) {
      html = html.replace(/<!--include:([a-z-]+)-->/g, function (m, name) {
        const f = path.join(partialsDir, name + '.html');
        return fs.existsSync(f) ? read(f) : '<!-- missing partial ' + name + ' -->';
      });
    }
    return html;
  }

  /* Returns { status, html } for a url path, or null when the path is not a page. */
  function render(urlPath, settings) {
    const route = Object.prototype.hasOwnProperty.call(ROUTES, urlPath) ? ROUTES[urlPath] : null;
    const file = route || '404';
    const f = path.join(publicDir, file + '.html');
    if (!fs.existsSync(f)) return null;
    let html = includes(read(f));

    /* highlight the current page in the menu */
    if (route) html = html.replace(new RegExp('(<a [^>]*data-nav="' + route + '")', 'g'), '$1 aria-current="page"');

    /* the home page's structured data comes from the live settings (phone, hours, cities) */
    if (route === 'index') {
      const s = settings;
      const ld = {
        '@context': 'https://schema.org', '@type': 'HomeAndConstructionBusiness', name: s.name,
        description: 'Residential, office, hostel, deep, move-in and move-out, regular and post-construction cleaning in Ibadan, Oyo, Ogbomoso, Osogbo, Ilorin and Lagos.',
        telephone: s.phone, email: s.email,
        areaServed: Pricing.RULES.cities.map(function (c) { return { '@type': 'City', name: c.name }; }),
        hasOfferCatalog: { '@type': 'OfferCatalog', name: 'Cleaning services', itemListElement: Object.keys(Pricing.PRICING.service).map(function (k) { return { '@type': 'Offer', itemOffered: { '@type': 'Service', name: Pricing.PRICING.service[k].label } }; }) },
        openingHoursSpecification: [{ '@type': 'OpeningHoursSpecification', dayOfWeek: Hours.ORDER.filter(function (d) { return s.hours.days[d]; }).map(function (d) { return DAY_NAMES[d]; }), opens: s.hours.open, closes: s.hours.close }]
      };
      if (publicUrl) { ld.url = publicUrl + '/'; ld.logo = publicUrl + '/img/logo-mark.png'; ld.image = publicUrl + '/img/og-image.png'; }
      html = html.replace(/<script type="application\/ld\+json">[\s\S]*?<\/script>/, '<script type="application/ld+json">' + JSON.stringify(ld).replace(/</g, '\\u003c') + '</script>');
    }
    if (route) {
      /* link previews (WhatsApp, Facebook, Google): the image must be an absolute address, so it needs PUBLIC_URL */
      let head = '<meta name="twitter:card" content="summary_large_image">\n';
      if (publicUrl) {
        const url = publicUrl + (urlPath === '/' ? '/' : urlPath);
        head += '<link rel="canonical" href="' + url + '">\n<meta property="og:url" content="' + url + '">\n<meta property="og:site_name" content="FreshNest Cleaning Services">\n' +
          '<meta property="og:image" content="' + publicUrl + '/img/og-image.png">\n<meta property="og:image:width" content="1200">\n<meta property="og:image:height" content="630">\n' +
          '<meta property="og:image:alt" content="FreshNest. Freshness You Can Feel.">\n';
      }
      html = html.replace('<link rel="icon"', head + '<link rel="icon"');
    }
    return { status: route ? 200 : 404, html: html };
  }

  function sitemap() {
    return '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' +
      Object.keys(ROUTES).map(function (r) { return '<url><loc>' + publicUrl + (r === '/' ? '/' : r) + '</loc></url>'; }).join('') + '</urlset>\n';
  }

  return { render: render, sitemap: sitemap, routes: Object.keys(ROUTES) };
}

module.exports = { createPages, ROUTES };
