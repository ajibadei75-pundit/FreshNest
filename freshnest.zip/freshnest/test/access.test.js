'use strict';
/* The first-run experience: a generated password, changing it, losing it, and resetting it. */
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

delete process.env.ADMIN_PASSWORD;
process.env.LOG_REQUESTS = 'off';
const { createApp } = require('../server/app');
const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'freshnest-access-'));
const servers = [];

async function start() {
  const app = createApp({ publicDir: path.join(__dirname, '..', 'public'), dataDir });
  const server = http.createServer(app.handler);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  servers.push([server, app]);
  return { app, base: 'http://127.0.0.1:' + server.address().port };
}
test.after(() => { servers.forEach(([s, a]) => { a.backups.stop(); s.closeAllConnections && s.closeAllConnections(); s.close(); }); fs.rmSync(dataDir, { recursive: true, force: true }); });

const login = (base, password) => fetch(base + '/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password }) });
const authed = (base, cookie) => (method, url, body) => fetch(base + url, { method, headers: { 'Content-Type': 'application/json', Cookie: cookie }, body: body === undefined ? undefined : JSON.stringify(body) }).then(async (r) => ({ status: r.status, data: await r.json().catch(() => ({})) }));

let first, cookie, firstPassword;

test('first start generates a password, and the Help tab data says it is still the first one', async () => {
  first = await start();
  firstPassword = first.app.generatedPassword;
  assert.ok(firstPassword && firstPassword.length >= 10, 'a generated password is available to print');
  const r = await login(first.base, firstPassword);
  assert.equal(r.status, 200);
  cookie = r.headers.get('set-cookie').split(';')[0];
  const sys = (await authed(first.base, cookie)('GET', '/api/admin/system')).data;
  assert.equal(sys.passwordManagedByEnv, false); assert.equal(sys.passwordChanged, false);
  assert.equal(sys.backupDownloadedAt, null);
  assert.equal(sys.sessionHours, 12); assert.equal(sys.loginAttempts, 8); assert.equal(sys.loginLockMinutes, 15);
});

test('downloading a backup is remembered for the setup checklist', async () => {
  const a = authed(first.base, cookie);
  assert.equal((await fetch(first.base + '/api/admin/backup', { headers: { Cookie: cookie } })).status, 200);
  assert.ok((await a('GET', '/api/admin/system')).data.backupDownloadedAt);
});

test('changing the password is remembered, and short or wrong ones are refused', async () => {
  const a = authed(first.base, cookie);
  assert.equal((await a('POST', '/api/admin/password', { current: 'wrong', next: 'a-new-long-password' })).status, 401);
  assert.equal((await a('POST', '/api/admin/password', { current: firstPassword, next: 'short' })).status, 422);
  const ok = await fetch(first.base + '/api/admin/password', { method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: cookie }, body: JSON.stringify({ current: firstPassword, next: 'my-own-new-password' }) });
  assert.equal(ok.status, 200);
  cookie = ok.headers.get('set-cookie').split(';')[0];
  assert.equal((await authed(first.base, cookie)('GET', '/api/admin/system')).data.passwordChanged, true);
  assert.equal((await login(first.base, firstPassword)).status, 401, 'the old password stops working');
  assert.equal((await login(first.base, 'my-own-new-password')).status, 200);
});

test('the lock-out message appears after eight wrong tries', async () => {
  let last;
  for (let i = 0; i < 9; i++) last = await login(first.base, 'nope-' + i);
  assert.equal(last.status, 429);
  assert.match((await last.json()).error, /15 minutes/);
});

test('npm run reset-password gets you back in, signs everyone else out, and keeps a copy of the old data', async () => {
  const run = (args) => spawnSync(process.execPath, [path.join(__dirname, '..', 'scripts', 'reset-password.js'), ...args], { env: { ...process.env, DATA_DIR: dataDir, ADMIN_PASSWORD: '' }, encoding: 'utf8' });

  const short = run(['tiny']); assert.equal(short.status, 1); assert.match(short.stderr, /at least 10 characters/);
  const out = run([]);
  assert.equal(out.status, 0, out.stderr);
  const printed = /New password:\s+(\S+)/.exec(out.stdout)[1];
  assert.ok(printed.length >= 10);
  assert.ok(fs.existsSync(path.join(dataDir, 'db.json.before-reset')), 'the old file is kept');

  const second = await start();                         /* a restart picks up the new file */
  assert.equal((await login(second.base, 'my-own-new-password')).status, 401, 'the old password no longer works');
  const r = await login(second.base, printed);
  assert.equal(r.status, 200, 'the printed password works');
  const sessions = await fetch(second.base + '/api/admin/summary', { headers: { Cookie: cookie } });
  assert.equal(sessions.status, 401, 'a session from before the reset is signed out');

  const chosen = run(['a password I chose myself']);
  assert.equal(chosen.status, 0); assert.ok(!/New password:/.test(chosen.stdout), 'a chosen password is not echoed');
  const third = await start();
  assert.equal((await login(third.base, 'a password I chose myself')).status, 200);
});

test('reset-password explains itself when there is nothing to reset', () => {
  const r = spawnSync(process.execPath, [path.join(__dirname, '..', 'scripts', 'reset-password.js')], { env: { ...process.env, DATA_DIR: path.join(dataDir, 'nope') }, encoding: 'utf8' });
  assert.equal(r.status, 1); assert.match(r.stderr, /No data found/);
});
