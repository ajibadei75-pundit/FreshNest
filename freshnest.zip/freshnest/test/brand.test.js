'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const { createPages } = require('../server/pages');
const { DEFAULT_SETTINGS } = require('../server/store');

const root = path.join(__dirname, '..'), pub = path.join(root, 'public'), img = (n) => path.join(pub, 'img', n), master = (n) => path.join(root, 'assets', 'logo', n);

/* WebP: check the container and read the real size and whether it carries transparency. */
function readWebp(file) {
  const b = fs.readFileSync(file);
  assert.equal(b.subarray(0, 4).toString(), 'RIFF', file + ' is a RIFF file'); assert.equal(b.subarray(8, 12).toString(), 'WEBP', file + ' is a WebP');
  assert.equal(b.readUInt32LE(4) + 8, b.length, 'declared length matches the file');
  const kind = b.subarray(12, 16).toString();
  if (kind === 'VP8X') return { w: 1 + b.readUIntLE(24, 3), h: 1 + b.readUIntLE(27, 3), alpha: !!(b[20] & 0x10), kind, bytes: b.length };
  if (kind === 'VP8L') return { w: 1 + (b.readUInt32LE(21) & 0x3fff), h: 1 + ((b.readUInt32LE(21) >> 14) & 0x3fff), alpha: !!((b.readUInt32LE(21) >> 28) & 1), kind, bytes: b.length };
  return { w: 0, h: 0, alpha: false, kind, bytes: b.length };
}

/* A small PNG reader (8-bit RGB or RGBA), enough to look at real pixels without any library. */
function readPng(file) {
  const b = fs.readFileSync(file);
  assert.equal(b.subarray(0, 8).toString('hex'), '89504e470d0a1a0a', file + ' is a PNG');
  let o = 8, ihdr = null; const idat = [];
  while (o < b.length) {
    const len = b.readUInt32BE(o), type = b.subarray(o + 4, o + 8).toString('latin1'), data = b.subarray(o + 8, o + 8 + len);
    if (type === 'IHDR') ihdr = { w: data.readUInt32BE(0), h: data.readUInt32BE(4), depth: data[8], color: data[9] };
    if (type === 'IDAT') idat.push(data);
    o += 12 + len;
  }
  assert.equal(ihdr.depth, 8, 'eight-bit pictures');
  const bpp = ihdr.color === 6 ? 4 : ihdr.color === 2 ? 3 : null;
  if (!bpp) return Object.assign(ihdr, { bpp: 0 });
  const raw = zlib.inflateSync(Buffer.concat(idat)), stride = ihdr.w * bpp, px = Buffer.alloc(ihdr.h * stride);
  for (let y = 0; y < ihdr.h; y++) {
    const f = raw[y * (stride + 1)], line = raw.subarray(y * (stride + 1) + 1, (y + 1) * (stride + 1));
    for (let x = 0; x < stride; x++) {
      const a = x >= bpp ? px[y * stride + x - bpp] : 0, up = y ? px[(y - 1) * stride + x] : 0, c = x >= bpp && y ? px[(y - 1) * stride + x - bpp] : 0;
      let v = line[x];
      if (f === 1) v += a; else if (f === 2) v += up; else if (f === 3) v += (a + up) >> 1;
      else if (f === 4) { const p = a + up - c, pa = Math.abs(p - a), pb = Math.abs(p - up), pc = Math.abs(p - c); v += pa <= pb && pa <= pc ? a : pb <= pc ? up : c; }
      px[y * stride + x] = v & 255;
    }
  }
  return Object.assign(ihdr, { bpp, px, at: (x, y) => Array.from(px.subarray(y * stride + x * bpp, y * stride + x * bpp + bpp)) });
}

test('logo pictures exist, have the right sizes, and are genuinely transparent', () => {
  const webp = { 'logo-mark-128': [128, 128], 'logo-disc': [236, 236], 'logo-droplet': [236, 236], 'logo-sparkle': [236, 236], 'logo-word': [777, 139], 'logo-word-light': [777, 139], 'logo-tag': [777, 60], 'logo-tag-light': [777, 60] };
  for (const [name, [w, h]] of Object.entries(webp)) {
    const wp = readWebp(img(name + '.webp')), pm = readPng(master(name + '.png'));
    assert.deepEqual([wp.w, wp.h], [w, h], name + '.webp size'); assert.deepEqual([pm.w, pm.h], [w, h], name + ' master size'); assert.ok(wp.alpha, name + '.webp keeps transparency');
    assert.ok(wp.bytes < fs.statSync(master(name + '.png')).size * 0.7, name + ' is much lighter than its PNG master');
  }
  const total = Object.keys(webp).filter((n) => !/light/.test(n)).reduce((a, n) => a + fs.statSync(img(n + '.webp')).size, 0);
  assert.ok(total < 40 * 1024, 'all the logo pieces a visitor downloads on a first visit weigh under 40 KB: ' + (total / 1024).toFixed(1) + ' KB');
  const want = { 'logo-mark.png': [236, 236], 'logo-full.png': [1056, 232], 'logo-full-light.png': [1056, 232],
    'favicon-32.png': [32, 32], 'icon-192.png': [192, 192], 'apple-touch-icon.png': [180, 180], 'og-image.png': [1200, 630] };
  for (const [name, [w, h]] of Object.entries(want)) { const p = readPng(img(name)); assert.deepEqual([p.w, p.h], [w, h], name); }
  for (const name of Object.keys(want).filter((n) => !/apple|og-image/.test(n))) assert.equal(readPng(img(name)).color, 6, name + ' has a transparency channel');
  assert.equal(readPng(img('apple-touch-icon.png')).color, 2, 'iOS icon is opaque (iOS paints transparency black)');

  const mark = readPng(img('logo-mark.png'));  /* the PNG master of the emblem is also served, for search engines */
  assert.equal(mark.at(2, 2)[3], 0, 'corner of the emblem is transparent, not a white box');
  assert.equal(mark.at(234, 234)[3], 0);
  assert.equal(mark.at(118, 118)[3], 255, 'middle of the emblem is solid');
  const disc = readPng(master('logo-disc.png')), drop = readPng(master('logo-droplet.png')), spark = readPng(master('logo-sparkle.png'));
  assert.equal(disc.at(118, 118)[3], 255); assert.equal(disc.at(1, 1)[3], 0);
  const opaque = (p) => { let n = 0; for (let i = 3; i < p.px.length; i += 4) if (p.px[i] > 200) n++; return n / (p.w * p.h); };
  assert.ok(opaque(disc) > 0.7 && opaque(disc) < 0.85, 'the disc is a circle filling most of its square: ' + opaque(disc).toFixed(2));
  assert.ok(opaque(drop) > 0.1 && opaque(drop) < 0.3, 'the droplet layer is only the droplet');
  assert.ok(opaque(spark) > 0.01 && opaque(spark) < 0.05, 'the sparkle layer is only the sparkle');
  assert.ok(drop.at(118, 118)[3] > 200 && spark.at(118, 118)[3] === 0, 'droplet is in the middle, sparkle is not');
  const gold = spark.at(178, 75); assert.ok(gold[3] > 200 && gold[0] > 200 && gold[2] < 140, 'the sparkle is gold: ' + gold);
  const w1 = readPng(master('logo-word.png')), w2 = readPng(master('logo-word-light.png'));
  let seenDark = false, seenLight = false, sameAlpha = true;
  for (let i = 0; i < w1.px.length; i += 4) {
    if (w1.px[i + 3] === 255) { seenDark = w1.px[i] < 20 && w1.px[i + 1] > 50 && w1.px[i + 1] < 90; seenLight = w2.px[i] > 220; }
    if (w1.px[i + 3] !== w2.px[i + 3]) sameAlpha = false;
  }
  assert.ok(seenDark && seenLight && sameAlpha, 'dark and light wordmarks have the same shape and different colours');
  assert.equal(w1.at(2, 2)[3], 0, 'no white box behind the wordmark');
});

test('favicon.ico holds three sizes and both manifests are valid and point at real icons', () => {
  const ico = fs.readFileSync(path.join(pub, 'favicon.ico'));
  assert.equal(ico.readUInt16LE(0), 0); assert.equal(ico.readUInt16LE(2), 1); assert.equal(ico.readUInt16LE(4), 3);
  for (const [file, start, scope, name] of [['site.webmanifest', '/', '/', /FreshNest Cleaning/], ['admin/admin.webmanifest', '/admin/', '/admin/', /Admin/]]) {
    const m = JSON.parse(fs.readFileSync(path.join(pub, file), 'utf8'));
    assert.equal(m.start_url, start); assert.equal(m.scope, scope); assert.match(m.name, name); assert.equal(m.display, 'standalone');
    assert.match(m.theme_color, /^#05342F$/i);
    assert.ok(m.icons.length >= 1);
    for (const i of m.icons) { assert.ok(fs.existsSync(path.join(pub, i.src.slice(1))), i.src + ' exists'); const p = readPng(path.join(pub, i.src.slice(1))); assert.equal(i.sizes, p.w + 'x' + p.h); }
  }
});

const pages = createPages({ publicDir: pub, partialsDir: path.join(root, 'partials'), publicUrl: 'https://www.freshnest.example' });
const bare = createPages({ publicDir: pub, partialsDir: path.join(root, 'partials'), publicUrl: '' });
const render = (p, pg = pages) => pg.render(p, DEFAULT_SETTINGS).html;

test('every page shows the logo in the header and footer, links home, and has the icons and manifest', () => {
  for (const route of pages.routes) {
    const html = render(route);
    const head = /<a class="brand-mark" href="\/" aria-label="FreshNest Cleaning Services, home">([\s\S]*?)<\/a>/.exec(html);
    assert.ok(head, route + ' header logo links home'); assert.match(head[1], /class="lockup compact"/); assert.match(head[1], /logo-mark-128\.webp/); assert.match(head[1], /logo-word\.webp/); assert.match(head[1], /logo-word-light\.webp/);
    assert.ok(!/logo-tag/.test(head[1]), 'the compact header logo has no tagline');
    const foot = /<a class="brand-mark on-deep"[\s\S]*?<\/a>/.exec(html);
    assert.ok(foot && /logo-tag-light\.webp/.test(foot[0]) && /logo-word-light\.webp/.test(foot[0]), route + ' footer logo has the tagline in light text');
    for (const tag of ['rel="icon" href="/favicon.ico"', 'rel="apple-touch-icon" href="/img/apple-touch-icon.png"', 'rel="manifest" href="/site.webmanifest"', 'name="theme-color" content="#05342F"']) assert.ok(html.includes(tag), route + ' has ' + tag);
    assert.ok(!/<circle cx="20" cy="20" r="20"/.test(html), route + ' no longer uses the placeholder drawn logo');
  }
});

test('every picture on every page has alt text (or is decorative), a size, and a file behind it', () => {
  for (const route of [...pages.routes, '/__missing']) {
    const html = render(route);
    for (const m of html.matchAll(/<img\b[^>]*>/g)) {
      const tag = m[0];
      assert.ok(/\balt="/.test(tag), route + ': ' + tag.slice(0, 80) + ' has an alt attribute');
      const w = /\bwidth="(\d+)"/.exec(tag), h = /\bheight="(\d+)"/.exec(tag); assert.ok(w && h, 'width and height stop the page jumping while it loads: ' + tag.slice(0, 80));
      const src = /\bsrc="([^"]+)"/.exec(tag)[1]; assert.ok(src.startsWith('/img/') && fs.existsSync(path.join(pub, src.slice(1))), src + ' exists');
      const file = path.join(pub, src.slice(1)), p = src.endsWith('.webp') ? readWebp(file) : readPng(file); assert.deepEqual([+w[1], +h[1]], [p.w, p.h], src + ' attributes match the real size');
    }
  }
});

test('light and dark logo pieces always come as a pair, and exactly one of each pair has a readable alt', () => {
  for (const route of pages.routes) {
    const html = render(route);
    for (const m of html.matchAll(/<span class="lk-(word|tag)">([\s\S]*?)<\/span>/g)) {
      const imgs = [...m[2].matchAll(/<img\b[^>]*>/g)].map((x) => x[0]);
      assert.equal(imgs.length, 2, route + ' ' + m[1] + ' has two versions');
      assert.ok(/class="lt"/.test(imgs[0]) && /class="dt"/.test(imgs[1]));
      assert.ok(/loading="lazy"/.test(imgs[1]) && !/loading="lazy"/.test(imgs[0]), 'the visible one loads first');
      assert.ok(imgs[1].includes('alt=""'), 'the hidden duplicate is not read out twice');
    }
  }
});

test('the home page has the welcome logo: four layers, wordmark and tagline, readable as one image', () => {
  const html = render('/');
  const logo = /<div class="lockup hero-logo" id="heroLogo"[\s\S]*?<\/div>\s*<h1/.exec(html);
  assert.ok(logo, 'welcome logo sits above the headline');
  assert.match(logo[0], /role="img" aria-label="FreshNest\. Freshness You Can Feel\."/);
  const order = [...logo[0].matchAll(/src="\/img\/(logo-[a-z-]+)\.webp"/g)].map((m) => m[1]);
  assert.deepEqual(order.slice(0, 3), ['logo-disc', 'logo-droplet', 'logo-sparkle'], 'layers stack disc, droplet, sparkle');
  for (const n of ['logo-word', 'logo-word-light', 'logo-tag', 'logo-tag-light']) assert.ok(order.includes(n), n);
  assert.equal((logo[0].match(/<i class="lk-s lk-s\d"/g) || []).length, 3, 'three small twinkles');
  assert.ok(!/alt="[^"]+"/.test(logo[0]), 'the pieces are decorative; the wrapper carries the label');
});

test('share previews: absolute picture address with PUBLIC_URL, a twitter card always, logo in structured data', () => {
  const html = render('/');
  assert.match(html, /<meta property="og:image" content="https:\/\/www\.freshnest\.example\/img\/og-image\.png">/);
  assert.match(html, /og:image:width" content="1200"/); assert.match(html, /og:image:height" content="630"/); assert.match(html, /og:image:alt/);
  assert.match(html, /<meta name="twitter:card" content="summary_large_image">/);
  const ld = JSON.parse(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/.exec(html)[1]);
  assert.equal(ld.logo, 'https://www.freshnest.example/img/logo-mark.png'); assert.equal(ld.image, 'https://www.freshnest.example/img/og-image.png');
  for (const route of pages.routes) assert.ok(render(route).includes('og:image'), route + ' has a share picture');
  const none = render('/', bare);
  assert.ok(!/og:image"/.test(none), 'a relative og:image would be invalid, so it is left out without PUBLIC_URL');
  assert.match(none, /twitter:card/);
});

test('logo animation is fenced behind "no reduced-motion preference", and the resting state is the finished logo', () => {
  const css = fs.readFileSync(path.join(pub, 'css', 'site.css'), 'utf8');
  const start = css.indexOf('@media (prefers-reduced-motion: no-preference) {\n  .hero-logo .lk-disc');
  assert.ok(start > 0, 'welcome animation block exists');
  let depth = 0, end = -1;
  for (let i = css.indexOf('{', start); i < css.length; i++) { if (css[i] === '{') depth++; if (css[i] === '}') { depth--; if (!depth) { end = i; break; } } }
  const block = css.slice(start, end), outside = css.slice(0, start) + css.slice(end);
  const rules = block.match(/\.hero-logo[^{]*\{[^}]*\}/g) || [];
  assert.ok(rules.length >= 9, 'every moving part is animated: ' + rules.length);
  for (const r of rules) assert.match(r, /animation:/, 'only animations live in the fenced block');
  assert.ok(!/\.hero-logo[^{]*\{[^}]*animation:/.test(outside), 'no hero-logo animation outside the fence');
  for (const r of rules) if (!/infinite/.test(r)) assert.match(r, /backwards/, 'a one-off animation hides the piece only until it starts, then rests as the finished logo: ' + r.slice(0, 60));
  for (const sel of ['.lk-ring', '.lk-s', '.lk-glint::before']) assert.match(outside, new RegExp(sel.replace(/[.:]/g, '\\$&') + '[^{]*\\{[^}]*opacity: 0'), sel + ' is invisible at rest (decorative only)');
  for (const sel of ['.lk-disc', '.lk-drop', '.lk-spark', '.lk-word', '.lk-tag']) assert.ok(!new RegExp('(^|\\n)\\' + sel + '[^{]*\\{[^}]*opacity: 0').test(outside), sel + ' is never hidden at rest');
  assert.match(fs.readFileSync(path.join(pub, 'css', 'base.css'), 'utf8'), /prefers-reduced-motion: reduce\)[\s\S]*animation: none !important/);
  assert.match(fs.readFileSync(path.join(pub, 'js', 'theme.js'), 'utf8'), /reveal-all/);
});

test('the palette keeps accessible contrast (WCAG AA) in light and dark mode', () => {
  const css = fs.readFileSync(path.join(pub, 'css', 'base.css'), 'utf8');
  const block = (re) => { const m = re.exec(css); assert.ok(m, 'token block found'); return Object.fromEntries([...m[1].matchAll(/--([\w-]+):\s*(#[0-9A-Fa-f]{6})/g)].map((x) => [x[1], x[2]])); };
  const light = block(/:root \{([\s\S]*?)\n\}/), dark = block(/:root\[data-theme="dark"\] \{([\s\S]*?)\n\}/);
  const lum = (h) => { const c = [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16) / 255).map((v) => v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; };
  const ratio = (a, b) => { const [x, y] = [lum(a), lum(b)].sort((p, q) => q - p); return (x + 0.05) / (y + 0.05); };
  const must = (t, pairs) => pairs.forEach(([a, b, name, min = 4.5]) => assert.ok(ratio(t[a] || a, t[b] || b) >= min, name + ' ' + ratio(t[a] || a, t[b] || b).toFixed(2) + ' needs ' + min));
  must(light, [['ink', 'bg', 'ink on page'], ['muted', 'bg', 'muted on page'], ['muted', 'surface-2', 'muted on tint'], ['brand', 'bg', 'links on page'], ['brand', 'brand-soft', 'brand text on soft tint'], ['on-brand', 'brand', 'button text'], ['sun-ink', 'sun', 'yellow button'], ['deep-ink', 'deep', 'footer text'], ['#014644', 'bg', 'logo wordmark on page', 7], ['#FFFFFF', '#12803F', 'WhatsApp button']]);
  must(dark, [['ink', 'bg', 'ink on page'], ['muted', 'bg', 'muted on page'], ['muted', 'surface', 'muted on cards'], ['brand', 'bg', 'links on page'], ['brand', 'brand-soft', 'brand on soft tint'], ['on-brand', 'brand', 'button text'], ['#E9F4F3', 'bg', 'light wordmark on page', 7], ['#E9F4F3', 'deep', 'light wordmark on footer', 7]]);
});
