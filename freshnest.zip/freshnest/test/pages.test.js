'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'freshnest-pages-'));
Object.assign(process.env, { ADMIN_PASSWORD: 'pages-test-password', PUBLIC_URL: 'https://www.freshnest.example', LOG_REQUESTS: 'off', TRUST_PROXY: '1' });
const { createApp } = require('../server/app');
const V = require('../server/validate');
const F = require('../public/js/pricing.js');
let server, base, app;

test.before(async () => {
  app = createApp({ publicDir: path.join(__dirname, '..', 'public'), dataDir });
  server = http.createServer(app.handler);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = 'http://127.0.0.1:' + server.address().port;
});
test.after(() => { app.backups.stop(); server.closeAllConnections && server.closeAllConnections(); server.close(); fs.rmSync(dataDir, { recursive: true, force: true }); });

const get = async (p) => { const r = await fetch(base + p, { redirect: 'manual' }); return { status: r.status, text: await r.text(), headers: r.headers }; };
const strip = (html) => html.replace(/<script[\s\S]*?<\/script>/g, '').replace(/<style[\s\S]*?<\/style>/g, '').replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ');

const PAGES = { '/': 'Home', '/services': 'Services', '/book': 'Book', '/locations': 'Locations', '/work': 'Our work', '/reviews': 'Reviews', '/faq': 'FAQ', '/contact': 'Contact', '/terms': 'Terms' };

test('every page is served, fully assembled, with its own title and canonical address', async () => {
  const titles = new Set();
  for (const p of Object.keys(PAGES)) {
    const r = await get(p);
    assert.equal(r.status, 200, p);
    assert.match(r.headers.get('content-type'), /text\/html/);
    assert.ok(!/<!--include/.test(r.text), p + ' has an unresolved include');
    assert.ok(/<header class="site-header"/.test(r.text) && /<footer class="site-footer"/.test(r.text), p + ' has header and footer');
    assert.ok(/<link rel="stylesheet" href="\/css\/base\.css">/.test(r.text), p + ' loads shared styles');
    assert.match(r.text, new RegExp('<link rel="canonical" href="https://www\\.freshnest\\.example' + (p === '/' ? '/' : p) + '">'));
    const t = /<title>([^<]+)<\/title>/.exec(r.text)[1]; assert.ok(!titles.has(t), 'duplicate title ' + t); titles.add(t);
    assert.ok(/<meta name="description" content="[^"]{20,}/.test(r.text), p + ' has a description');
  }
});

test('the menu marks the current page', async () => {
  for (const [p, key] of [['/services', 'services'], ['/locations', 'locations'], ['/work', 'work'], ['/reviews', 'reviews'], ['/faq', 'faq'], ['/contact', 'contact']]) {
    const r = await get(p);
    const current = r.text.match(/<a [^>]*aria-current="page"[^>]*>/g) || [];
    assert.equal(current.length, 1, p);
    assert.ok(current[0].includes('data-nav="' + key + '"'), p + ' marks ' + key);
  }
});

test('clean addresses: .html and trailing slashes redirect, unknown pages get the friendly 404', async () => {
  for (const [from, to] of [['/services.html', '/services'], ['/services/', '/services'], ['/index.html', '/'], ['/book.html?service=deep', '/book?service=deep']]) {
    const r = await get(from); assert.equal(r.status, 301, from); assert.equal(r.headers.get('location'), to);
  }
  const nf = await get('/nothing-here');
  assert.equal(nf.status, 404); assert.match(nf.text, /could not find that page/); assert.match(nf.text, /<footer class="site-footer"/);
  assert.equal((await get('/nope.png')).status, 404);
  assert.equal((await get('/partials/header.html')).status, 404, 'partials are not public');
  assert.equal((await get('/../partials/header.html')).status, 404);
});

test('the Services page lists exactly the seven services, by name and in order', async () => {
  const names = ['Residential Cleaning', 'Office & Commercial Cleaning', 'Deep Cleaning', 'Hostel Cleaning', 'Move-in & Move-out Cleaning', 'One-time & Regular Cleaning', 'Post-Construction Cleaning'];
  assert.deepEqual(Object.keys(F.PRICING.service).map((k) => F.PRICING.service[k].label), names, 'pricing uses the same seven');
  const r = await get('/services');
  const h2s = [...r.text.matchAll(/<article class="sd" id="([a-z]+)"[\s\S]*?<h2>([^<]+)<\/h2>/g)].map((m) => [m[1], m[2].replace(/&amp;/g, '&')]);
  assert.deepEqual(h2s.map((x) => x[1]), names);
  assert.deepEqual(h2s.map((x) => x[0]), Object.keys(F.PRICING.service), 'anchors match booking keys');
  for (const [key] of h2s) assert.ok(r.text.includes('href="/book?service=' + key + '"'), key + ' links to booking');
  assert.ok(!/windows and glass/i.test(strip((await get('/')).text)), 'old Windows service is gone from the home page');
  const home = (await get('/')).text;
  assert.equal((home.match(/class="svc-card"/g) || []).length, 7, 'home shows seven cards');
  for (const n of names) assert.ok(strip(home).includes(n), n + ' on home');
});

test('only our six cities appear, everywhere', async () => {
  const cities = ['Ibadan', 'Oyo', 'Ogbomoso', 'Osogbo', 'Ilorin', 'Lagos'];
  assert.deepEqual(F.RULES.cities.map((c) => c.name), cities);
  const loc = await get('/locations');
  const cards = [...loc.text.matchAll(/<article class="city-card"[\s\S]*?<h2>([^<]+)<\/h2>/g)].map((m) => m[1]);
  assert.deepEqual(cards, cities);
  for (const c of cities) assert.ok(loc.text.includes('href="/book?city=' + c + '"'));
  const home = await get('/');
  const chips = [...home.text.matchAll(/<a class="city" href="\/book\?city=([A-Za-z]+)"/g)].map((m) => m[1]);
  assert.deepEqual(chips, cities);
  const ld = JSON.parse(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/.exec(home.text)[1]);
  assert.deepEqual(ld.areaServed.map((a) => a.name), cities);
  assert.equal(ld.hasOfferCatalog.itemListElement.length, 7);
  const foot = (await get('/contact')).text;
  for (const c of cities) assert.ok(foot.includes('>' + c + '</a>'), c + ' in footer');
});

test('bookings are accepted for each city and each service, and refused elsewhere', async () => {
  const post = (b) => fetch(base + '/api/bookings', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': '10.0.0.' + Math.floor(Math.random() * 250) }, body: JSON.stringify(b) }).then(async (r) => ({ status: r.status, data: await r.json() }));
  const mk = (type, city) => ({
    selection: { type, rooms: {}, kitchen: 'standard', open: 'small' },
    details: { date: V.lagosDate(3), street: '12 Example Street', city },
    contact: { name: 'Ada Obi', phone: '0801 234 5678' }, consent: { accepted: true }
  });
  for (const c of F.RULES.cities) { const r = await post(mk('residential', c.name)); assert.equal(r.status, 201, c.name); }
  for (const k of Object.keys(F.PRICING.service)) { const r = await post(mk(k, 'Lagos')); assert.equal(r.status, 201, k); }
  for (const bad of ['Abuja', 'Kano', 'ibadan', '', undefined]) {
    const r = await post(mk('residential', bad));
    assert.equal(r.status, 422, String(bad)); assert.equal(r.data.field, 'city'); assert.match(r.data.error, /Ibadan, Oyo, Ogbomoso, Osogbo, Ilorin, Lagos/);
  }
  assert.equal((await post(mk('windows', 'Ibadan'))).status, 422, 'removed service is refused');
  assert.equal((await post(mk('standard', 'Ibadan'))).status, 422, 'old key is refused');
});

test('the server prices hostel, office and home bookings from their own room lists', async () => {
  const cookie = (await fetch(base + '/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: 'pages-test-password' }) })).headers.get('set-cookie').split(';')[0];
  const mk = (sel) => ({ selection: sel, details: { date: V.lagosDate(3), street: '12 Example Street', city: 'Ilorin' }, contact: { name: 'Hostel Owner', phone: '08012345678' }, consent: { accepted: true } });
  const post = (b) => fetch(base + '/api/bookings', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': '172.16.0.' + Math.floor(Math.random() * 250) }, body: JSON.stringify(b) });
  const sel = { type: 'hostel', rooms: { room: 20, bathroom: 4, toilet: 4, kitchen: 2, common: 1, corridor: 4, bedroom: 99 }, freq: 'once' };
  await post(mk(sel));
  const list = (await (await fetch(base + '/api/admin/bookings?q=Hostel', { headers: { Cookie: cookie } })).json()).bookings;
  const b = list[0];
  const want = F.estimate({ type: 'hostel', rooms: { room: 20, bathroom: 4, toilet: 4, kitchen: 2, common: 1, corridor: 4 }, freq: 'once' });
  assert.equal(b.estimate.low, want.low); assert.equal(b.estimate.high, want.high);
  assert.ok(b.estimate.lines.some((l) => /20 student rooms/.test(l.label)));
  assert.equal(b.sel.rooms.bedroom, undefined, 'rooms from another service are dropped');
  assert.equal(b.details.state, 'Kwara'); assert.equal(b.details.city, 'Ilorin');
});

test('hostel, regular and the other services price sensibly', () => {
  const P = F.PRICING, est = (type, o) => F.estimate(Object.assign({ type, size: 'average', cond: 'normal', kitchen: 'standard', open: 'none', rooms: {}, freq: 'once' }, o), P);
  assert.ok(est('hostel', { rooms: { room: 40 } }).total > est('hostel', { rooms: { room: 10 } }).total, 'more rooms cost more');
  assert.equal(est('hostel', { rooms: { room: 1 } }).total, P.hostel.min, 'hostel minimum charge');
  assert.equal(est('regular', { rooms: { bedroom: 2 } }).total, est('residential', { rooms: { bedroom: 2 } }).total, 'regular and residential share a price per visit');
  assert.ok(est('regular', { rooms: { bedroom: 2 }, freq: 'weekly' }).total < est('regular', { rooms: { bedroom: 2 } }).total);
  const r = { bedroom: 3, bathroom: 2, living: 1 };
  assert.ok(est('deep', { rooms: r }).total > est('residential', { rooms: r }).total);
  assert.ok(est('construction', { rooms: r }).total > est('residential', { rooms: r }).total);
  assert.equal(est('hostel', { rooms: { room: 20 }, extras: ['oven'] }).extraLines.length, 0, 'home-only extras are ignored for hostels');
  assert.equal(est('office', { extras: ['carpet'], rooms: { private: 3 } }).extraLines.length, 1);
  assert.equal(est('residential', { extraWindows: 3, rooms: { bedroom: 2 } }).extraLines[0].label, '3 windows, inside');
  for (const set of Object.keys(F.PRESETS)) for (const p of F.PRESETS[set]) {
    const rooms = F.roomSet(P, set).map((d) => d.id);
    for (const id of Object.keys(p.rooms)) assert.ok(rooms.includes(id), set + ' preset ' + p.label + ' uses a real room: ' + id);
  }
});

test('shared text and settings reach pages: terms, contact details, no leftover single-page content', async () => {
  const faq = strip((await get('/faq')).text);
  assert.match(faq, /Ibadan, Oyo, Ogbomoso, Osogbo, Ilorin and Lagos/);
  for (const n of ['Residential Cleaning', 'Hostel Cleaning', 'Post-Construction Cleaning']) assert.ok(faq.includes(n));
  const all = (await Promise.all(Object.keys(PAGES).map(async (p) => strip((await get(p)).text)))).join(' ');
  assert.ok(!/sample/i.test(all), 'no sample content');
  assert.ok(!/every city and state/i.test(all), 'no claim of working in every state');
  assert.ok(!/windows and glass/i.test(all));
});
