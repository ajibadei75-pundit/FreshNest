'use strict';
/* The one-folder preview (npm run build:preview) must work with no server: links resolve between files,
   and booking falls back to email and WhatsApp. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { pathToFileURL } = require('node:url');

let jsdom = null; try { jsdom = require('jsdom'); } catch (e) { /* optional */ }
const skip = jsdom ? false : 'jsdom is not installed';
const root = path.join(__dirname, '..'), site = path.join(root, 'dist', 'site');
const V = require('../server/validate');

test.before(() => {
  const r = spawnSync(process.execPath, [path.join(root, 'scripts', 'build-preview.js')], { encoding: 'utf8' });
  assert.equal(r.status, 0, r.stderr);
});

test('every page is built and every internal link points at a file that exists', () => {
  const pages = ['index', 'services', 'book', 'locations', 'work', 'reviews', 'faq', 'contact', 'terms', '404'];
  for (const p of pages) {
    const html = fs.readFileSync(path.join(site, p + '.html'), 'utf8');
    assert.ok(!/(href|src)="\/[^/]/.test(html) && !/(href|src)="\/"/.test(html), p + ' has a root-absolute link');
    assert.ok(!/Staff login/.test(html), 'no staff login in a static preview');
    for (const m of html.matchAll(/(?:href|src)="([^"#:]+?)(?:[?#][^"]*)?"/g)) {
      const target = m[1]; if (/^(https?|tel|mailto):/.test(target) || target === '') continue;
      assert.ok(fs.existsSync(path.join(site, target)), p + ' links to missing ' + target);
    }
  }
  assert.ok(!/\bhref="\/book"/.test(fs.readFileSync(path.join(site, 'js', 'work.js'), 'utf8')), 'links inside scripts are rewritten too');
});

async function open(file, query) {
  const { JSDOM, VirtualConsole } = jsdom, errors = [], vc = new VirtualConsole();
  vc.on('jsdomError', (e) => { if (!/Not implemented: navigation|fonts\.googleapis\.com/.test(e.message)) errors.push(e.message); });
  const dom = await JSDOM.fromFile(path.join(site, file), {
    url: pathToFileURL(path.join(site, file)).href + (query || ''), runScripts: 'dangerously', resources: 'usable', pretendToBeVisual: true, virtualConsole: vc,
    beforeParse(w) {
      w.matchMedia = (q) => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {} });
      w.scrollTo = () => {}; w.Element.prototype.scrollIntoView = function () {};
      w.IntersectionObserver = class { observe() {} unobserve() {} disconnect() {} };
      w.HTMLDialogElement.prototype.showModal = function () { this.setAttribute('open', ''); };
      w.fetch = () => Promise.reject(new Error('offline'));
    }
  });
  if (dom.window.document.readyState !== 'complete') await new Promise((r) => dom.window.addEventListener('load', r));
  await new Promise((r) => setTimeout(r, 150));
  return { w: dom.window, d: dom.window.document, errors, $: (id) => dom.window.document.getElementById(id) };
}
const click = (w, el) => el.dispatchEvent(new w.MouseEvent('click', { bubbles: true, cancelable: true }));
const type = (w, el, v) => { el.value = v; el.dispatchEvent(new w.Event('input', { bubbles: true })); el.dispatchEvent(new w.Event('change', { bubbles: true })); };

test('the home page works offline from files', { skip }, async () => {
  const p = await open('index.html');
  assert.deepEqual(p.errors, []);
  assert.equal(p.d.querySelectorAll('.svc-card').length, 7);
  assert.match(p.d.querySelector('[data-status-text]').textContent, /Open now|Closed now/);
  assert.equal(p.d.querySelector('.svc-card a.btn').getAttribute('href'), 'book.html?service=residential');
  assert.equal(p.$('homeReviews').hidden, true);
  p.w.close();
});

test('booking offline: the service in the link is chosen, and sending falls back to email', { skip }, async () => {
  const p = await open('book.html', '?service=deep&city=Lagos'), w = p.w, $ = p.$;
  assert.deepEqual(p.errors, []);
  assert.equal(p.d.querySelector('input[name="type"]:checked').value, 'deep');
  assert.equal(p.d.querySelector('.step[data-step="2"]').hidden, false);
  click(w, $('nextBtn')); click(w, $('nextBtn'));
  type(w, $('date'), V.lagosDate(4)); type(w, $('street'), '5 Example Road'); click(w, $('nextBtn'));
  const t = $('terms'); Object.defineProperty(t, 'clientHeight', { get: () => 50 }); Object.defineProperty(t, 'scrollHeight', { get: () => 50 }); t.dispatchEvent(new w.Event('scroll'));
  type(w, $('name'), 'Ada Obi'); type(w, $('phone'), '08012345678'); $('consent').checked = true;
  click(w, $('sendEmail'));
  await new Promise((r) => setTimeout(r, 400));
  assert.match($('status').textContent, /couldn't reach our booking server/);
  assert.ok($('status').querySelector('#copyMsg'), 'a copy-message button is offered');
  assert.equal($('success').hidden, true);
  w.close();
});
