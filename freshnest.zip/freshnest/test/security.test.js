'use strict';
/* Text typed by customers (names, addresses, reviews) and by staff (project titles) must only ever be shown as text.
   The pages below are loaded with scripts switched ON, so an injected <script> or onerror would really run. */
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

let jsdom = null; try { jsdom = require('jsdom'); } catch (e) { /* optional */ }
const skip = jsdom ? false : 'jsdom is not installed';
const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'freshnest-sec-'));
Object.assign(process.env, { ADMIN_PASSWORD: 'security-test-password', TRUST_PROXY: '1', LOG_REQUESTS: 'off' });
const { createApp } = require('../server/app');
const V = require('../server/validate');
let server, base, app, cookie = '';
const windows = [];

const HOSTILE = {
  img: '<img src=x onerror="window.__xss=1">',
  script: '"><script>window.__xss=2</script>',
  svg: '<svg onload="window.__xss=3"></svg>',
  link: '<a href="javascript:window.__xss=4">click</a>'
};

test.before(async () => {
  app = createApp({ publicDir: path.join(__dirname, '..', 'public'), dataDir });
  server = http.createServer(app.handler);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = 'http://127.0.0.1:' + server.address().port;
  cookie = (await fetch(base + '/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: 'security-test-password' }) })).headers.get('set-cookie').split(';')[0];
});
test.after(() => { windows.forEach((w) => { try { w.close(); } catch (e) { /* ignore */ } }); app.backups.stop(); server.closeAllConnections && server.closeAllConnections(); server.close(); fs.rmSync(dataDir, { recursive: true, force: true }); });

const admin = (method, url, body) => fetch(base + url, { method, headers: { 'Content-Type': 'application/json', Cookie: cookie }, body: body === undefined ? undefined : JSON.stringify(body) }).then(async (r) => ({ status: r.status, data: await r.json().catch(() => ({})) }));
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

async function open(pathname, withCookie) {
  const { JSDOM, VirtualConsole, requestInterceptor } = jsdom, vc = new VirtualConsole(); vc.on('jsdomError', () => {});
  const jar = { cookie: withCookie ? cookie : '' };
  const dom = await JSDOM.fromURL(base + pathname, {
    runScripts: 'dangerously', pretendToBeVisual: true, virtualConsole: vc,
    resources: { interceptors: [requestInterceptor((request) => { if (request.url.startsWith(base) && !/\.(css|png|ico)(\?|$)/.test(request.url)) return undefined; return new Response('', { headers: { 'Content-Type': 'text/css' } }); })] },
    beforeParse(w) {
      w.matchMedia = (q) => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {} });
      w.scrollTo = () => {}; w.Element.prototype.scrollIntoView = function () {}; w.IntersectionObserver = class { observe() {} unobserve() {} disconnect() {} };
      w.HTMLDialogElement.prototype.showModal = function () { this.setAttribute('open', ''); }; w.HTMLDialogElement.prototype.close = function () { this.removeAttribute('open'); this.dispatchEvent(new w.Event('close')); };
      w.fetch = (u, o = {}) => fetch(new URL(u, base), Object.assign({}, o, { headers: Object.assign({}, o.headers, jar.cookie ? { Cookie: jar.cookie } : {}) }));
    }
  });
  windows.push(dom.window);
  if (dom.window.document.readyState !== 'complete') await new Promise((r) => dom.window.addEventListener('load', r));
  const w = dom.window;
  const t0 = Date.now(); while (Date.now() - t0 < 3000) { if (!w.FN || w.FN.loaded) break; await wait(20); }
  await wait(60);
  return { w, d: w.document, $: (id) => w.document.getElementById(id) };
}
function assertSafe(p, where) {
  assert.equal(p.w.__xss, undefined, where + ': injected code ran (' + p.w.__xss + ')');
  assert.equal(p.d.querySelector('img[src="x"]'), null, where + ': injected <img> exists');
  assert.equal(p.d.querySelector('svg[onload]'), null, where + ': injected <svg onload> exists');
  assert.equal(p.d.querySelector('a[href^="javascript:"]'), null, where + ': javascript: link exists');
  assert.equal([...p.d.querySelectorAll('script')].filter((s) => /__xss/.test(s.textContent)).length, 0, where + ': injected <script> exists');
  assert.equal(p.d.querySelectorAll('[onerror],[onload],[onclick]').length, 0, where + ': event-handler attributes exist');
}

test('hostile text in bookings, reviews and projects is stored as plain text', async () => {
  const booking = await fetch(base + '/api/bookings', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': '203.0.113.5' }, body: JSON.stringify({
    selection: { type: 'residential', rooms: { bedroom: 2 } },
    details: { date: V.lagosDate(3), street: HOSTILE.script, city: 'Ibadan', landmark: HOSTILE.img, instructions: HOSTILE.svg, otherRooms: HOSTILE.link, petType: HOSTILE.img },
    contact: { name: HOSTILE.img, phone: '08012345678', email: 'a@b.co' }, consent: { accepted: true }, message: HOSTILE.script }) });
  assert.equal(booking.status, 201);
  const fb = await fetch(base + '/api/feedback', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': '203.0.113.6' }, body: JSON.stringify({ rating: 5, text: HOSTILE.img + ' ' + HOSTILE.link, name: HOSTILE.svg, allowPublic: true }) });
  assert.equal(fb.status, 201);
  const id = (await admin('GET', '/api/admin/feedback')).data.feedback[0].id;
  assert.equal((await admin('PATCH', '/api/admin/feedback/' + id, { status: 'published' })).status, 200);
  const pr = await admin('POST', '/api/admin/projects', { title: HOSTILE.img, service: HOSTILE.svg, date: '2026-09-20', excerpt: HOSTILE.script, property: HOSTILE.link, team: HOSTILE.img, time: HOSTILE.svg, body: '## ' + HOSTILE.img + '\n- ' + HOSTILE.svg + '\n' + HOSTILE.script, published: true });
  assert.equal(pr.status, 201);
});

test('public pages show hostile text as text and run nothing', { skip }, async () => {
  const reviews = await open('/reviews');
  assertSafe(reviews, '/reviews');
  assert.ok(reviews.$('reviewList').textContent.includes('<img src=x'), 'the review text is visible as literal text');
  const home = await open('/'); assertSafe(home, '/');
  assert.ok(home.$('homeReviewList').textContent.includes('<svg onload'), 'home strip shows the name as text');
  const work = await open('/work'); assertSafe(work, '/work');
  assert.ok(work.$('posts').textContent.includes('<img src=x'), 'project title shown as text');
  work.w.FN.qsa('#posts .post').find((b) => b.textContent.includes('<img src=x')).dispatchEvent(new work.w.MouseEvent('click', { bubbles: true }));
  await wait(50); assertSafe(work, '/work (project opened)');
  assert.ok(work.$('readerBody').textContent.includes('<script>window.__xss=2'), 'project details shown as text');
  for (const route of ['/services', '/locations', '/faq', '/contact', '/terms', '/book', '/book?service=<img src=x onerror=window.__xss=5>&city="><script>window.__xss=6</script>']) assertSafe(await open(route), route);
});

test('the admin page shows hostile text as text and runs nothing', { skip }, async () => {
  const p = await open('/admin/', true);
  const t0 = Date.now(); while (Date.now() - t0 < 4000 && !p.$('stats').children.length) await wait(30);
  assertSafe(p, 'admin overview');
  for (const tab of ['bookings', 'reviews', 'projects']) { p.$('tab-' + tab).dispatchEvent(new p.w.MouseEvent('click', { bubbles: true })); await wait(40); assertSafe(p, 'admin ' + tab); }
  p.$('tab-bookings').dispatchEvent(new p.w.MouseEvent('click', { bubbles: true }));
  const row = p.d.querySelector('#bookingList .item'); assert.ok(row.textContent.includes('<img src=x'), 'customer name visible as literal text');
  row.dispatchEvent(new p.w.MouseEvent('click', { bubbles: true })); await wait(60);
  assertSafe(p, 'admin booking details');
  const body = p.$('bookingBody').textContent;
  for (const bit of ['<script>window.__xss=2', '<svg onload', '<img src=x']) assert.ok(body.includes(bit), 'booking details show ' + bit + ' literally');
});

test('the server hands out hostile text only as data, never as a page', async () => {
  const list = await admin('GET', '/api/admin/bookings');
  assert.equal(list.data.bookings[0].contact.name, HOSTILE.img);       /* kept exactly as typed ... */
  const home = await (await fetch(base + '/')).text();
  assert.ok(!home.includes('__xss'), '... but never written into a served page');
  const csv = await (await fetch(base + '/api/admin/bookings.csv', { headers: { Cookie: cookie } })).text();
  assert.ok(csv.includes('"<img src=x') || csv.includes("\"'") || csv.includes('<img'), 'export contains the text');
  const csp = (await fetch(base + '/')).headers.get('content-security-policy');
  assert.equal(/script-src ([^;]+)/.exec(csp)[1], "'self'", 'scripts may only come from our own server: no inline scripts, no eval, no other sites');
  assert.ok(!/unsafe-eval/.test(csp) && /frame-ancestors 'none'/.test(csp) && /object-src 'none'/.test(csp));
});
