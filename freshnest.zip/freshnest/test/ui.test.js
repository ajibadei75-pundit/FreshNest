'use strict';
/* Loads the real public site and admin page from a real running server inside
   jsdom and drives them like a visitor and like the owner would.
   jsdom has no layout engine, so scrolling is simulated. Skipped if jsdom is not installed. */
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

let jsdom = null;
try { jsdom = require('jsdom'); } catch (e) { /* optional */ }
const skip = jsdom ? false : 'jsdom is not installed (npm install to enable UI tests)';

const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'freshnest-ui-'));
process.env.ADMIN_PASSWORD = 'ui-test-password';
const { createApp } = require('../server/app');
const V = require('../server/validate');

let server, base, adminCookie = '';
const windows = [];

test.before(async () => {
  const app = createApp({ publicDir: path.join(__dirname, '..', 'public'), dataDir });
  server = http.createServer(app.handler);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = 'http://127.0.0.1:' + server.address().port;
  const r = await fetch(base + '/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: 'ui-test-password' }) });
  adminCookie = r.headers.get('set-cookie').split(';')[0];
});
test.after(() => { windows.forEach((w) => { try { w.close(); } catch (e) { /* ignore */ } }); server.closeAllConnections && server.closeAllConnections(); server.close(); fs.rmSync(dataDir, { recursive: true, force: true }); });

async function admin(method, url, body) {
  const r = await fetch(base + url, { method, headers: { 'Content-Type': 'application/json', Cookie: adminCookie }, body: body === undefined ? undefined : JSON.stringify(body) });
  return { status: r.status, data: await r.json().catch(() => ({})) };
}
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
async function waitFor(fn, ms = 3000, what = 'condition') {
  const end = Date.now() + ms;
  while (Date.now() < end) { try { if (fn()) return; } catch (e) { /* keep waiting */ } await wait(20); }
  throw new Error('Timed out waiting for ' + what);
}

async function openPage(pathname) {
  const { JSDOM, VirtualConsole, requestInterceptor } = jsdom, errors = [], jar = { cookie: '' };
  const vc = new VirtualConsole();
  vc.on('jsdomError', (e) => errors.push(e.message + (e.detail ? ' ' + e.detail : '')));
  vc.on('error', (m) => errors.push(String(m)));
  /* Only our own scripts are loaded. Stylesheets and fonts are not needed here (there is no layout engine). */
  const resources = {
    interceptors: [requestInterceptor((request) => {
      if (request.url.startsWith(base) && /\.js(\?|$)/.test(request.url)) return undefined;
      if (request.url.startsWith(base) && !/\.(css|svg)(\?|$)/.test(request.url)) return undefined;   /* the page itself and API calls */
      return new Response('', { headers: { 'Content-Type': 'text/css' } });
    })]
  };
  const dom = await JSDOM.fromURL(base + pathname, {
    runScripts: 'dangerously', resources, pretendToBeVisual: true, virtualConsole: vc,
    beforeParse(w) {
      w.matchMedia = (q) => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} });
      w.scrollTo = () => {}; w.Element.prototype.scrollIntoView = function () {};
      w.IntersectionObserver = class { observe() {} unobserve() {} disconnect() {} };
      w.HTMLDialogElement.prototype.showModal = function () { this.setAttribute('open', ''); };
      w.HTMLDialogElement.prototype.close = function () { if (!this.hasAttribute('open')) return; this.removeAttribute('open'); this.dispatchEvent(new w.Event('close')); };
      w.fetch = (u, o = {}) => {
        const headers = Object.assign({}, o.headers); if (jar.cookie) headers.Cookie = jar.cookie;
        return fetch(new URL(u, base), Object.assign({}, o, { headers })).then((r) => {
          const sc = r.headers.get('set-cookie');
          if (sc) jar.cookie = /fn_admin=;/.test(sc) ? '' : sc.split(';')[0];
          return r;
        });
      };
    }
  });
  windows.push(dom.window);
  if (dom.window.document.readyState !== 'complete') await new Promise((r) => dom.window.addEventListener('load', r));
  return { window: dom.window, document: dom.window.document, errors, $: (id) => dom.window.document.getElementById(id) };
}
function click(w, el) { el.dispatchEvent(new w.MouseEvent('click', { bubbles: true, cancelable: true })); }
function type(w, el, value) { el.value = value; el.dispatchEvent(new w.Event('input', { bubbles: true })); el.dispatchEvent(new w.Event('change', { bubbles: true })); }
function isoIn(days) { return V.lagosDate(days); }

/* ------------------------------------------------------------------ public site */
const CITIES = ['Ibadan', 'Oyo', 'Ogbomoso', 'Osogbo', 'Ilorin', 'Lagos'];

test('home: loads cleanly, shows live status, seven services and six cities, no fake content', { skip }, async () => {
  const p = await openPage('/');
  await waitFor(() => p.window.FN && p.window.FN.loaded, 3000, 'settings from /api/public');
  assert.deepEqual(p.errors, [], 'no script errors');
  assert.match(p.document.querySelector('[data-status-text]').textContent, /^(Open now|Closed now)$/);
  assert.ok(p.document.querySelector('[data-status-detail]').textContent.length > 0);
  assert.equal(p.document.querySelector('[data-s="hoursText"]').textContent, 'Every day, 7am to 7pm');
  assert.match(p.document.querySelector('h1').textContent, /A clean you can see\./);
  assert.equal(p.document.querySelectorAll('.svc-card').length, 7);
  assert.deepEqual([...p.document.querySelectorAll('.city b')].map((b) => b.textContent), CITIES);
  assert.equal(p.$('homeReviews').hidden, true, 'no reviews strip until real reviews exist');
  assert.ok(!/sample/i.test(p.document.body.textContent));
  assert.ok(p.document.querySelector('[data-reveal]'), 'reveal hooks present');
  assert.ok(p.document.querySelector('.svc-card').style.getPropertyValue('--i') !== '' || true);
  /* welcome logo: layers in place, and a click plays it again */
  const logo = p.$('heroLogo');
  assert.equal(logo.querySelectorAll('img').length, 7, 'disc, droplet, sparkle, then wordmark and tagline in light and dark text');
  assert.deepEqual([...logo.querySelectorAll('.lk-emblem img')].map((i) => i.className), ['lk-disc', 'lk-drop', 'lk-spark']);
  const dropBefore = logo.querySelector('.lk-drop');
  click(p.window, logo);
  assert.notEqual(logo.querySelector('.lk-drop'), dropBefore, 'clicking the logo restarts its animation (the pieces are rebuilt)');
  assert.equal(logo.querySelectorAll('img').length, 7, 'and nothing is lost');
  assert.equal(p.document.querySelector('.site-header .lockup.compact img[src$="logo-mark-128.webp"]') !== null, true, 'header carries the compact logo');
  const stag = [...p.document.querySelectorAll('.svc-grid > .svc-card')].map((c) => c.style.getPropertyValue('--i'));
  assert.deepEqual(stag.slice(0, 4), ['0', '1', '2', '3'], 'cards are staggered');
});

test('header: the mobile menu opens, locks scrolling and closes again', { skip }, async () => {
  const p = await openPage('/services'), w = p.window;
  assert.equal(p.$('nav').getAttribute('data-open'), null);
  click(w, p.$('navToggle'));
  assert.equal(p.$('nav').getAttribute('data-open'), 'true');
  assert.equal(p.$('navToggle').getAttribute('aria-expanded'), 'true');
  assert.ok(p.document.documentElement.classList.contains('menu-open'));
  assert.ok(p.$('nav').querySelector('.nav-extra a[href="/book"]'), 'menu has a Book now button');
  assert.ok(p.$('nav').querySelector('.nav-extra a[href^="tel:"]') && p.$('nav').querySelector('.nav-extra a[href^="https://wa.me/"]'));
  click(w, p.$('nav').querySelector('a[href="/faq"]'));
  assert.equal(p.$('nav').getAttribute('data-open'), 'false');
  assert.ok(!p.document.documentElement.classList.contains('menu-open'));
  assert.equal(p.document.querySelectorAll('.nav > a[aria-current="page"]').length, 1);
  assert.deepEqual(p.errors, []);
});

test('services: seven services with checklists, jump bar and book links', { skip }, async () => {
  const p = await openPage('/services#hostel'); await waitFor(() => p.window.FN.loaded);
  assert.equal(p.document.querySelectorAll('.sd').length, 7);
  assert.equal(p.document.querySelectorAll('.jump a').length, 7);
  assert.ok(p.document.querySelector('.jump a[data-k="hostel"]').classList.contains('active'), 'the jump bar highlights the service in the address');
  assert.match(p.$('hostel').textContent, /Shared bathrooms and toilets/);
  assert.deepEqual(p.errors, []);
});

test('book: a service and city from a link skip straight to rooms, with hostel layouts and live pricing', { skip }, async () => {
  const p = await openPage('/book?service=hostel&city=Ilorin'), w = p.window, $ = p.$;
  await waitFor(() => w.FN.loaded);
  assert.deepEqual(p.errors, []);
  assert.equal($('city').value, 'Ilorin');
  assert.equal(p.document.querySelector('input[name="type"]:checked').value, 'hostel');
  assert.equal(p.document.querySelector('.step[data-step="2"]').hidden, false, 'started on the rooms step');
  assert.equal(p.document.querySelector('.grp-hostel').hidden, false);
  assert.equal(p.document.querySelector('.grp-home').hidden, true);
  assert.equal(p.document.querySelector('.grp-office').hidden, true);
  assert.equal(p.document.querySelector('.only-home').hidden, true, 'property type is hidden for hostels');
  assert.equal($('roomsTitle').textContent, 'What does your hostel include?');
  assert.deepEqual([...p.document.querySelectorAll('#presets .preset b')].map((b) => b.textContent), ['10 rooms', '20 rooms', '40 rooms']);
  assert.match($('abPrice').textContent, /₦\d/, 'price shows in the bottom bar');

  const total = () => $('brkList').querySelector('li.tot span:last-child').textContent;
  const before = total();
  click(w, p.document.querySelector('#presets .preset[data-i="2"]'));
  assert.equal($('r_hostel_room').value, '40');
  assert.equal(p.document.querySelector('#presets .preset[data-i="2"]').getAttribute('aria-pressed'), 'true');
  assert.notEqual(total(), before, 'price changed');
  click(w, $('r_hostel_room').parentNode.querySelector('[data-d="1"]'));
  assert.equal($('r_hostel_room').value, '41');
  assert.equal(p.document.querySelector('#presets .preset[data-i="2"]').getAttribute('aria-pressed'), 'false', 'preset un-highlights once adjusted');
  assert.match($('brkList').textContent, /41 student rooms/);

  click(w, $('openSheet'));
  assert.ok($('sheet').hasAttribute('open')); assert.match($('sheetList').textContent, /41 student rooms/); assert.match($('sheetPrice').textContent, /₦/);
  click(w, $('sheetClose')); assert.ok(!$('sheet').hasAttribute('open'));
});

test('book: consent unlocks only after the terms are read, then the booking is saved with its city', { skip }, async () => {
  const p = await openPage('/book?service=residential&city=Lagos'), w = p.window, $ = p.$;
  await waitFor(() => w.FN.loaded);
  assert.equal($('freqSeg').querySelector('input:checked').value, 'once', 'a single visit by default');

  click(w, p.document.querySelector('#presets .preset[data-i="1"]'));            /* 2 bedrooms */
  assert.equal($('r_home_bedroom').value, '2');
  click(w, $('nextBtn')); click(w, $('nextBtn'));                               /* rooms -> extras -> when and where */
  click(w, $('nextBtn'));
  assert.match($('dateErr').textContent, /Choose the date/); assert.match($('streetErr').textContent, /street address/);
  assert.match($('cityEcho').textContent, /Lagos/);
  type(w, $('date'), isoIn(4)); type(w, $('street'), '12 Example Street, Lekki');
  click(w, $('nextBtn'));
  assert.equal($('nextBtn').hidden, true, 'now on the last step');
  assert.equal($('terms').children.length, 11, 'terms are filled in from one source');

  const terms = $('terms'); let top = 0;
  Object.defineProperty(terms, 'clientHeight', { get: () => 230 });
  Object.defineProperty(terms, 'scrollHeight', { get: () => 1000 });
  Object.defineProperty(terms, 'scrollTop', { get: () => top, set: (v) => { top = v; }, configurable: true });
  const scrollTo = (v) => { top = v; terms.dispatchEvent(new w.Event('scroll')); };
  assert.equal($('consent').disabled, true, 'locked at the start');
  click(w, $('consentLine'));
  assert.match($('consentErr').textContent, /read the terms to the end/i);
  scrollTo(300); assert.equal($('consent').disabled, true); assert.match($('readText').textContent, /\d+% read/);
  scrollTo(770); assert.equal($('consent').disabled, false, 'unlocked at the bottom');
  scrollTo(0); assert.equal($('consent').disabled, false, 'stays unlocked once read');

  type(w, $('name'), 'Ada Obi'); type(w, $('phone'), '0801 234 5678'); type(w, $('email'), 'ada@example.com');
  click(w, $('sendEmail')); await wait(50);
  assert.match($('consentErr').textContent, /tick the box/i);
  assert.equal($('success').hidden, true, 'nothing sent without consent');
  assert.equal((await admin('GET', '/api/admin/bookings')).data.bookings.length, 0);

  $('consent').checked = true; $('consent').dispatchEvent(new w.Event('change', { bubbles: true }));
  click(w, $('sendEmail'));
  await waitFor(() => !$('success').hidden, 3000, 'success view');
  assert.match($('refCode').textContent, /^FN-\d{6}-[0-9A-F]{4}$/);
  assert.deepEqual(p.errors, []);
  const saved = (await admin('GET', '/api/admin/bookings')).data.bookings;
  assert.equal(saved.length, 1);
  assert.equal(saved[0].estimate.label, 'Residential Cleaning');
  assert.equal(saved[0].details.city, 'Lagos'); assert.equal(saved[0].details.state, 'Lagos');
  assert.equal(saved[0].details.street, '12 Example Street, Lekki');
  assert.equal(saved[0].contact.phone, '+2348012345678'); assert.equal(saved[0].consent.accepted, true);
  assert.equal(saved[0].sel.rooms.bedroom, 2);
});

test('book: starting fresh asks for a city, defaults the plan per service, and shows the extras that fit', { skip }, async () => {
  const p = await openPage('/book'), w = p.window, $ = p.$; await waitFor(() => w.FN.loaded);
  assert.equal(p.document.querySelectorAll('#tiles .tile').length, 7);
  assert.deepEqual([...$('city').options].slice(1).map((o) => o.value), CITIES);
  assert.equal(p.document.querySelector('.step[data-step="1"]').hidden, false);
  click(w, $('nextBtn'));
  assert.match($('cityErr').textContent, /Choose the city/);
  assert.equal(p.document.querySelector('.step[data-step="2"]').hidden, true, 'cannot continue without a city');
  type(w, $('city'), 'Osogbo'); assert.equal($('cityErr').textContent, '');

  const pick = (v) => { const r = p.document.querySelector('input[name="type"][value="' + v + '"]'); r.checked = true; r.dispatchEvent(new w.Event('change', { bubbles: true })); };
  pick('regular');
  assert.equal($('freqSeg').querySelector('input:checked').value, 'fortnight', 'regular cleaning starts on a fortnightly plan');
  pick('deep'); assert.equal($('freqSeg').querySelector('input:checked').value, 'once');
  const f = $('freqSeg').querySelector('input[value="weekly"]'); f.checked = true; f.dispatchEvent(new w.Event('change', { bubbles: true }));
  pick('residential'); assert.equal($('freqSeg').querySelector('input:checked').value, 'weekly', 'a plan the customer chose is kept');

  pick('office');
  assert.equal(p.document.querySelector('.grp-office').hidden, false);
  assert.equal(p.document.querySelector('.grp-hostel').hidden, true);
  assert.deepEqual([...p.document.querySelectorAll('#presets .preset b')].map((b) => b.textContent), ['Small office', 'Medium office', 'Large office']);
  const homeOnly = [...p.document.querySelectorAll('#extras .chk')].filter((l) => l.getAttribute('data-for') === 'home');
  assert.ok(homeOnly.length >= 3 && homeOnly.every((l) => l.hidden), 'home-only extras are hidden for offices');
  pick('hostel'); assert.ok(homeOnly.every((l) => l.hidden));
  pick('residential'); assert.ok(homeOnly.some((l) => !l.hidden));
  assert.deepEqual(p.errors, []);
});

test('book: a failed field from the server is shown on the right step', { skip }, async () => {
  const p = await openPage('/book?service=residential&city=Ibadan'), w = p.window, $ = p.$; await waitFor(() => w.FN.loaded);
  /* make the client believe a past date is fine so the server's own check is what answers */
  $('date').removeAttribute('min'); $('date').max = '2099-01-01';
  click(w, $('nextBtn')); click(w, $('nextBtn'));
  type(w, $('date'), '2031-01-01'); type(w, $('street'), '12 Example Street');
  click(w, $('nextBtn'));
  assert.equal($('nextBtn').hidden, true);
  const terms = $('terms'); Object.defineProperty(terms, 'clientHeight', { get: () => 100 }); Object.defineProperty(terms, 'scrollHeight', { get: () => 100 }); terms.dispatchEvent(new w.Event('scroll'));
  assert.equal($('consent').disabled, false, 'terms that need no scrolling unlock at once');
  type(w, $('name'), 'Bo Ade'); type(w, $('phone'), '08012345678'); $('consent').checked = true;
  click(w, $('sendEmail'));
  await waitFor(() => /within the next/.test(($('dateErr') || {}).textContent || '') || !$('status').hidden, 3000, 'server answer');
  assert.equal(p.document.querySelector('.step[data-step="4"]').hidden, false, 'jumped back to the step with the problem');
  assert.match($('dateErr').textContent, /within the next \d+ days/);
});

test('book: paused online booking disables sending and says why', { skip }, async () => {
  const cur = (await admin('GET', '/api/admin/settings')).data.settings;
  await admin('PUT', '/api/admin/settings', { ...cur, acceptingBookings: false });
  const p = await openPage('/book'); await waitFor(() => p.window.FN.loaded);
  assert.equal(p.$('closedNotice').hidden, false); assert.equal(p.$('sendEmail').disabled, true);
  await admin('PUT', '/api/admin/settings', { ...cur, acceptingBookings: true });
});

test('admin-published projects, reviews and announcements appear on the right pages', { skip }, async () => {
  const s = (await admin('GET', '/api/admin/settings')).data.settings;
  await admin('PUT', '/api/admin/settings', { ...s, announcement: 'Open on all public holidays' });
  assert.equal((await admin('POST', '/api/admin/projects', { title: 'Ring Road office clean', service: 'Office & Commercial Cleaning', date: '2026-09-20', excerpt: 'Weekly evening clean.', published: true })).status, 201);
  const fb = await fetch(base + '/api/feedback', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ rating: 5, text: 'Spotless flat, on time.', name: 'Tunde', service: 'Residential Cleaning', allowPublic: true }) });
  assert.equal(fb.status, 201);
  const id = (await admin('GET', '/api/admin/feedback')).data.feedback[0].id;
  await admin('PATCH', '/api/admin/feedback/' + id, { status: 'published' });

  const home = await openPage('/'); await waitFor(() => home.window.FN.loaded);
  assert.equal(home.$('announce').hidden, false); assert.equal(home.$('announce').textContent, 'Open on all public holidays');
  assert.equal(home.$('homeReviews').hidden, false, 'reviews strip appears once a real review is published');
  assert.match(home.$('homeReviewList').textContent, /Spotless flat, on time\./);

  const work = await openPage('/work'); await waitFor(() => work.window.FN.loaded);
  assert.equal(work.$('filters').hidden, false);
  assert.equal(work.$('workTitle').textContent, 'Our work and cleaning tips');
  assert.ok([...work.document.querySelectorAll('#posts .post h3')].some((h) => h.textContent === 'Ring Road office clean'));
  click(work.window, work.document.querySelector('#filters [data-f="work"]'));
  assert.equal(work.document.querySelectorAll('#posts .post').length, 1);
  click(work.window, work.document.querySelector('#posts .post'));
  assert.ok(work.$('reader').hasAttribute('open')); assert.match(work.$('readerBody').textContent, /Ring Road office clean/);
  assert.ok(work.$('readerBody').querySelector('a[href="/book"]'));

  const rev = await openPage('/reviews'); await waitFor(() => rev.window.FN.loaded);
  assert.equal(rev.document.querySelector('#reviewList .empty'), null);
  assert.match(rev.$('reviewList').textContent, /Tunde/); assert.match(rev.$('reviewList').textContent, /Residential Cleaning/);
});

test('work: before real projects exist only cleaning tips show, without filters', { skip }, async () => {
  const fresh = fs.mkdtempSync(path.join(os.tmpdir(), 'fn-work-'));
  const { createApp: make } = require('../server/app');
  const app2 = make({ publicDir: path.join(__dirname, '..', 'public'), dataDir: fresh });
  const s2 = http.createServer(app2.handler); await new Promise((r) => s2.listen(0, '127.0.0.1', r));
  const saved = base; base = 'http://127.0.0.1:' + s2.address().port;
  try {
    const p = await openPage('/work'); await waitFor(() => p.window.FN.loaded);
    assert.equal(p.document.querySelectorAll('#posts .post').length, 3);
    assert.equal(p.$('filters').hidden, true); assert.equal(p.$('workTitle').textContent, 'Cleaning tips');
    const r = await openPage('/reviews'); await waitFor(() => r.window.FN.loaded);
    assert.ok(r.document.querySelector('#reviewList .empty'), 'honest empty state for reviews');
  } finally { base = saved; app2.backups.stop(); s2.closeAllConnections(); s2.close(); fs.rmSync(fresh, { recursive: true, force: true }); }
});

test('reviews: the feedback form sends to the server and waits for approval', { skip }, async () => {
  const p = await openPage('/reviews'), w = p.window; await waitFor(() => w.FN.loaded);
  assert.ok([...p.$('fbService').options].some((o) => o.text === 'Hostel Cleaning'), 'service list uses the seven services');
  click(w, p.$('fbEmail'));
  assert.match(p.$('rateErr').textContent, /star rating/);
  click(w, p.$('r4')); type(w, p.$('fbText'), 'Good work'); type(w, p.$('fbName'), 'Ngozi');
  click(w, p.$('fbEmail'));
  await waitFor(() => !p.$('fbStatus').hidden, 3000, 'feedback status');
  assert.match(p.$('fbStatus').textContent, /Thank you/);
  const mine = (await admin('GET', '/api/admin/feedback')).data.feedback.find((f) => f.name === 'Ngozi');
  assert.ok(mine); assert.equal(mine.status, 'pending'); assert.equal(mine.allowPublic, false);
  assert.ok(!/Ngozi/.test(p.$('reviewList').textContent), 'only approved reviews are shown');
});

test('faq: search filters questions, highlights matches and clears again', { skip }, async () => {
  const p = await openPage('/faq'), w = p.window; await waitFor(() => w.FN.loaded);
  const all = p.document.querySelectorAll('#faqList details').length;
  assert.ok(all >= 20, 'full FAQ: ' + all);
  type(w, p.$('faqSearch'), 'hostel'); await wait(250);
  const shown = [...p.document.querySelectorAll('#faqList details')].filter((d) => !d.hidden);
  assert.ok(shown.length >= 1 && shown.length < all);
  assert.ok(shown.every((d) => /hostel/i.test(d.textContent)));
  assert.ok(p.document.querySelector('#faqList mark'), 'matches are highlighted');
  assert.match(p.$('faqCount').textContent, /answers? found/);
  type(w, p.$('faqSearch'), 'zzzzqq'); await wait(250);
  assert.equal(p.$('faqEmpty').hidden, false);
  type(w, p.$('faqSearch'), ''); await wait(250);
  assert.equal([...p.document.querySelectorAll('#faqList details')].filter((d) => d.hidden).length, 0);
  assert.equal(p.$('faqEmpty').hidden, true);
  assert.equal(p.document.querySelector('#faqList mark'), null);
  assert.deepEqual(p.errors, []);
});

test('contact: hours table, today highlighted, and open status', { skip }, async () => {
  const p = await openPage('/contact'); await waitFor(() => p.window.FN.loaded);
  const rows = [...p.document.querySelectorAll('#hoursTable tr')];
  assert.equal(rows.length, 7);
  assert.deepEqual(rows.map((r) => r.cells[0].textContent.replace(' (today)', '')), ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']);
  assert.ok(rows.every((r) => /^7am to 7pm$/.test(r.cells[1].textContent)), 'open all seven days');
  assert.equal(p.document.querySelectorAll('#hoursTable tr.today').length, 1);
  assert.match(p.document.querySelector('.page-hero [data-status-text]').textContent, /Open now|Closed now/);
  assert.ok(p.document.querySelector('a.c-card[href^="https://wa.me/2348"]') || p.document.querySelector('a.c-card.wa'));
});

test('terms: the full terms page is filled from the same source as the booking form', { skip }, async () => {
  const p = await openPage('/terms'); await waitFor(() => p.window.FN.loaded);
  assert.equal(p.document.querySelectorAll('#termsDoc section').length, 11);
  assert.match(p.$('termsVersion').textContent, /Version 2026-10-02/);
  assert.match(p.$('termsDoc').textContent, /Ibadan, Oyo, Ogbomoso, Osogbo, Ilorin and Lagos/);
  assert.match(p.$('termsDoc').textContent, /freshnestcleaningservices@proton\.me/);
});

/* ------------------------------------------------------------------ admin page */
test('admin: sign in, Help tab, bookings, project, hours, sign out', { skip }, async () => {
  const p = await openPage('/admin/'), w = p.window, $ = p.$;
  await waitFor(() => !$('login').hidden, 3000, 'login screen');
  assert.equal($('app').hidden, true);
  assert.match($('login').textContent, /forgot the password/i, 'sign-in screen explains what to do if you are locked out');
  assert.ok($('login').querySelector('.lockup img[src$="logo-tag.webp"]'), 'sign-in screen shows the full logo with its tagline');
  assert.ok(p.document.querySelector('.a-header .lockup.compact') && /Admin/.test(p.document.querySelector('.a-brand .tagpill').textContent), 'admin header shows the logo and an Admin label');

  type(w, $('password'), 'wrong password');
  $('loginForm').dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
  await waitFor(() => /not right/.test($('loginErr').textContent), 3000, 'wrong-password message');
  type(w, $('password'), 'ui-test-password');
  $('loginForm').dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
  await waitFor(() => !$('app').hidden && $('stats').children.length > 0, 4000, 'dashboard');
  assert.deepEqual(p.errors, []);
  assert.match($('cnt-bookings').textContent, /^1$/);
  assert.equal($('alertHint').hidden, false, 'overview warns that no alert channel is set up');
  assert.equal($('setupHint').hidden, false, 'overview points to the setup checklist');

  /* Help tab */
  click(w, $('tab-help'));
  assert.equal($('panel-help').hidden, false); assert.equal($('panel-overview').hidden, true);
  const items = [...p.document.querySelectorAll('#setupList li')];
  assert.equal(items.length, 7);
  const state = Object.fromEntries(items.map((li) => [li.querySelector('b').textContent.replace(' (optional)', '').trim(), li.classList.contains('done')]));
  assert.equal(state['Booking alerts are on'], false);
  assert.equal(state['The password is your own'], true, 'the password comes from ADMIN_PASSWORD on this server');
  assert.equal(state['You have received a booking'], true);
  assert.equal(state['You have downloaded a backup'], false);
  assert.match($('setupProgress').textContent, /\d of 6 essentials done/);
  const access = $('accessList').textContent;
  assert.match(access, /\/admin\//); assert.match(access, /12 hours/); assert.match(access, /8 wrong passwords/); assert.match(access, /Forgot the password/);
  assert.ok(access.includes('ADMIN_PASSWORD'), 'access details explain the password is set on the server');
  assert.ok(p.document.querySelectorAll('#panel-help .guide').length >= 8, 'step-by-step guides');
  assert.match($('panel-help').textContent, /A new booking arrives/); assert.match($('panel-help').textContent, /You are fully booked/);
  click(w, p.document.querySelector('#setupList [data-go="settings"]'));
  assert.equal($('panel-settings').hidden, false, '"Go there" opens the right tab');

  /* bookings tab and detail dialog */
  click(w, $('tab-bookings'));
  const row = p.document.querySelector('#bookingList .item');
  assert.match(row.textContent, /Ada Obi/); assert.match(row.textContent, /Residential Cleaning/);
  click(w, row);
  await waitFor(() => $('bookingDlg').hasAttribute('open'), 2000, 'booking dialog');
  const body = $('bookingBody').textContent;
  assert.match(body, /\+2348012345678/); assert.match(body, /Lagos, Lagos State/); assert.match(body, /12 Example Street, Lekki/); assert.match(body, /Terms accepted/);
  assert.ok($('bookingBody').querySelector('a[href^="https://wa.me/2348012345678"]')); assert.ok($('bookingBody').querySelector('a[href^="tel:"]'));
  $('bkStatus').value = 'confirmed'; type(w, $('bkPrice'), '32000'); type(w, $('bkNotes'), 'Gate code 4321');
  $('bkForm').dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
  await waitFor(() => !$('bookingDlg').hasAttribute('open'), 3000, 'dialog closes after save');
  const b = (await admin('GET', '/api/admin/bookings')).data.bookings[0];
  assert.equal(b.status, 'confirmed'); assert.equal(b.finalPrice, 32000); assert.equal(b.notes, 'Gate code 4321');
  await waitFor(() => $('cnt-bookings').hidden, 3000, 'badge clears');

  /* reviews: a private one cannot be published */
  click(w, $('tab-reviews'));
  await waitFor(() => p.document.querySelector('#reviewList .rv'), 2000, 'review cards');
  const pending = p.document.querySelector('#reviewList .rv');
  assert.match(pending.textContent, /Ngozi/); assert.equal(pending.querySelector('[data-act="published"]').disabled, true);

  /* projects: the service list uses the seven services */
  click(w, $('tab-projects')); click(w, $('addProject'));
  await waitFor(() => $('projectDlg').hasAttribute('open'), 2000, 'project dialog');
  assert.deepEqual([...$('pjService').options].slice(1).map((o) => o.text), ['Residential Cleaning', 'Office & Commercial Cleaning', 'Deep Cleaning', 'Hostel Cleaning', 'Move-in & Move-out Cleaning', 'One-time & Regular Cleaning', 'Post-Construction Cleaning']);
  type(w, $('pjName'), 'Bodija hostel deep clean'); type(w, $('pjDate'), '2026-09-25'); $('pjService').value = 'Hostel Cleaning'; $('pjPub').checked = true;
  $('pjForm').dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
  await waitFor(() => !$('projectDlg').hasAttribute('open'), 3000, 'project saved');
  assert.ok((await admin('GET', '/api/admin/projects')).data.projects.some((x) => x.title === 'Bodija hostel deep clean' && x.published));

  /* settings: close on Sundays */
  click(w, $('tab-settings'));
  assert.match($('hoursPreview').textContent, /Every day, 7am to 7pm/);
  const sun = p.document.querySelector('#sDays input[data-day="0"]'); sun.checked = false; sun.dispatchEvent(new w.Event('change', { bubbles: true }));
  assert.match($('hoursPreview').textContent, /Mon to Sat, 7am to 7pm/);
  $('settingsForm').dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
  await waitFor(() => /Settings saved/.test($('toast').textContent), 3000, 'settings toast');
  const s = (await admin('GET', '/api/admin/settings')).data.settings;
  assert.equal(s.hours.days[0], false);

  const site = await openPage('/contact'); await waitFor(() => site.window.FN.loaded);
  assert.equal(site.document.querySelector('[data-s="hoursText"]').textContent, 'Mon to Sat, 7am to 7pm');
  assert.match([...site.document.querySelectorAll('#hoursTable tr')].find((r) => /Sunday/.test(r.cells[0].textContent)).cells[1].textContent, /Closed/);

  click(w, $('logoutBtn'));
  await waitFor(() => !$('login').hidden && $('app').hidden, 3000, 'back at login');
});
